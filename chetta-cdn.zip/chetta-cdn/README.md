# Chetta.xyz — CDN-ready Build

## File Structure
```
chetta-cdn/
├── index.html        ← Main HTML (193 KB)
├── css/
│   └── chetta.css    ← All styles (49 KB)
├── js/
│   └── chetta.js     ← All application logic (151 KB)
├── netlify.toml      ← Netlify deployment config
├── vercel.json       ← Vercel deployment config
├── _headers          ← CDN cache headers
└── README.md
```

## Deploy in 60 seconds

### Option 1: Netlify (Recommended — FREE)
1. Go to https://app.netlify.com/drop
2. Drag the entire `chetta-cdn` folder onto the page
3. Your site is live instantly with a .netlify.app domain
4. Add custom domain `chetta.xyz` in Site Settings → Domain Management

### Option 2: Vercel (FREE)
1. Install: `npm i -g vercel`
2. Run: `cd chetta-cdn && vercel`
3. Follow prompts — site deploys in seconds
4. Add chetta.xyz in Vercel dashboard → Domains

### Option 3: Cloudflare Pages (FREE + fastest CDN)
1. Go to https://pages.cloudflare.com
2. Connect GitHub repo or upload folder
3. Build command: (none — static site)
4. Output directory: `.`
5. Add chetta.xyz domain (if already on Cloudflare)

### Option 4: GitHub Pages (FREE)
1. Create repo: `chetta-xyz`
2. Upload all files
3. Settings → Pages → Branch: main → Folder: / (root)
4. Site live at username.github.io/chetta-xyz
5. Add CNAME file with `chetta.xyz` for custom domain

## Performance
- CSS cached for 1 year in CDN (49 KB)
- JS cached for 1 year in CDN (151 KB, loads once)  
- HTML always fresh (193 KB — no cache)
- Fonts loaded from Google Fonts CDN
- SEO: Open Graph, Twitter Cards, JSON-LD schema, canonical URL

## To activate AI Advisor
1. Get free Gemini API key: https://aistudio.google.com/app/apikey
2. Click AI Advisor in nav → enter key when prompted
3. Key stored in browser localStorage — private
