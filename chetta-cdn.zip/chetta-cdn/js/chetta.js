/* Chetta.xyz — Application JS v2.0 */


const unis=[
  {id:1,name:"Massachusetts Institute of Technology",short:"MIT",loc:"Cambridge, USA",region:"usa",emoji:"⚛",rank:"#1 World",acc:3.97,tuition:57986,sat:"1510–1580",gpa:"3.9+",type:"Research University",url:"https://mit.edu",diff:98,tags:["STEM","Research","Engineering"],desc:"MIT is the world's leading STEM university, renowned for hands-on innovation. Its culture of building and solving real problems has produced more Nobel laureates per faculty than any other institution in the world.",majors:["Computer Science","Electrical Engineering","Physics","Mathematics","Aerospace","Biology","Economics"],scholarships:["MIT Need-Based Aid","Fulbright","Gates Cambridge"],roadmap:["Score 1550+ SAT or 35+ ACT","Maintain 3.9+ unweighted GPA in rigorous courses","Research experience, hackathons, or significant projects","Essays showing 'mind and hand' — curiosity + practical application","Two teacher recommendations + counselor letter","Apply by November 1 (EA) or January 1 (RD)"]},
  {id:2,name:"Harvard University",short:"Harvard",loc:"Cambridge, USA",region:"usa",emoji:"🏛",rank:"#4 World",acc:3.6,tuition:59076,sat:"1500–1580",gpa:"3.9+",type:"Ivy League",url:"https://harvard.edu",diff:97,tags:["Ivy League","Liberal Arts","Research"],desc:"Harvard is America's oldest university and the gold standard in higher education. Its holistic admissions values extraordinary achievement, authentic storytelling, and intellectual curiosity above all else.",majors:["Law","Medicine","Business","Economics","Political Science","Computer Science","History"],scholarships:["Harvard Financial Aid","Harvard Club Scholarships","Fulbright"],roadmap:["Score 1500+ SAT or 34+ ACT","Top of class GPA in rigorous coursework","Exceptional extracurriculars showing deep leadership","Compelling, specific personal narrative in all essays","Two strong academic recommendations + counselor letter","Apply by November 1 (REA) or January 1 (RD)"]},
  {id:3,name:"University of Oxford",short:"Oxford",loc:"Oxford, UK",region:"uk",emoji:"🎓",rank:"#1 UK",acc:17,tuition:9535,sat:"A*AA – A*A*A",gpa:"A*AA minimum",type:"Collegiate University",url:"https://ox.ac.uk",diff:92,tags:["Research","UK","Liberal Arts"],desc:"Oxford is the oldest English-speaking university in the world. Its tutorial system — one-on-one weekly sessions with world experts — provides unparalleled academic depth across every subject.",majors:["PPE","Law","Medicine","Computer Science","History","Philosophy","Engineering"],scholarships:["Rhodes Scholarship","Clarendon Fund","Oxford-Weidenfeld"],roadmap:["Predicted A*AA or above in A-Levels","Submit UCAS application by October 15","Sit subject admissions test (TSA/MAT/BMAT/LNAT)","Attend college interview in December","Conditional offer based on final A-Level grades","Confirm place and arrange college accommodation"]},
  {id:4,name:"Stanford University",short:"Stanford",loc:"Stanford, USA",region:"usa",emoji:"🌲",rank:"#3 World",acc:3.68,tuition:61731,sat:"1500–1570",gpa:"3.9+",type:"Research University",url:"https://stanford.edu",diff:96,tags:["Tech","Entrepreneurship","Research"],desc:"Stanford sits at the heart of Silicon Valley and is the launchpad for Google, Netflix, HP, and thousands of startups. It blends elite academics with an entrepreneurial culture unlike anywhere else.",majors:["CS","Engineering","Business","Biology","Economics","Human Biology","Design"],scholarships:["Stanford Need-Based Aid","Knight-Hennessy Scholars","NSF Fellowship"],roadmap:["Score 1500+ SAT or 34+ ACT","Demonstrate entrepreneurial or creative real-world impact","Show 'intellectual vitality' — what you think about for fun","Strong research, startup, or creative project outside class","Apply by November 1 (REA) or January 1 (RD)","Two teacher recommendations + counselor"]},
  {id:5,name:"University of Toronto",short:"UofT",loc:"Toronto, Canada",region:"canada",emoji:"🍁",rank:"#21 World",acc:43,tuition:6100,sat:"N/A",gpa:"3.7+",type:"Public Research",url:"https://utoronto.ca",diff:68,tags:["Canada","Public","Research"],desc:"Canada's #1 university offers world-class education at a fraction of US costs. Located in downtown Toronto — one of the world's most multicultural cities — it's a top destination for international students.",majors:["Engineering","Life Sciences","Computer Science","Commerce","Arts & Science","Law"],scholarships:["Lester B. Pearson Scholarship","U of T International Awards","Ontario Graduate Scholarship"],roadmap:["Strong secondary school transcripts (top of class)","IELTS 6.5+ for most international applicants","Apply via OUAC by February 1","Some programs require portfolio or reference letters","Pearson Scholarship application deadline: November","Accept offer and pay enrollment deposit by May"]},
  {id:6,name:"ETH Zurich",short:"ETH Zürich",loc:"Zurich, Switzerland",region:"europe",emoji:"⚗",rank:"#7 World",acc:27,tuition:730,sat:"N/A",gpa:"Top national grades",type:"Technical University",url:"https://ethz.ch",diff:82,tags:["STEM","Europe","Affordable"],desc:"Europe's answer to MIT — ranked alongside it globally — but with tuition under CHF 1,000 per semester. ETH Zürich is one of the best-value elite STEM universities on the planet.",majors:["Engineering","Computer Science","Physics","Architecture","Mathematics","Environmental Science"],scholarships:["ETH Excellence Scholarship","Swiss Government Scholarships","DAAD"],roadmap:["Excellent mathematics and science grades nationally","German required for most BSc programs (English for MSc)","Bachelor via direct entry or one-year preparatory course","Strong motivation letter for Master's applications","Some programs have entrance examinations","Master's programs are highly internationally competitive"]},
  {id:7,name:"National University of Singapore",short:"NUS",loc:"Singapore",region:"asia",emoji:"🦁",rank:"#8 World",acc:17,tuition:17550,sat:"N/A",gpa:"Top 10% nationally",type:"Public Research",url:"https://nus.edu.sg",diff:78,tags:["Asia","Tech","Research"],desc:"Asia's leading global university. NUS blends Eastern and Western academic traditions in Singapore — a global financial and tech hub that creates extraordinary career opportunities in Asia-Pacific.",majors:["Engineering","Computing","Business","Law","Medicine","Arts & Social Sciences"],scholarships:["ASEAN Undergraduate Scholarship","NUS Global Merit Scholarship","Lee Kuan Yew Scholarship"],roadmap:["Excellent A-Level or IB results","Apply via NUS Admissions Portal (January–February)","IELTS 6.0+ or TOEFL 85+ for international students","Interview required for Medicine and Law","Scholarship applications are separate from admission","Conditional offer letter issued after review"]},
,
  {id:9,name:"Yale University",short:"Yale",loc:"New Haven, USA",region:"usa",emoji:"🔵",rank:"#9 World",acc:4.6,tuition:62250,sat:"1500-1570",gpa:"3.9+",type:"Ivy League",url:"https://yale.edu",diff:96,tags:["Ivy League","Arts","Law"],desc:"Yale is renowned for its drama and arts programs, law school, and political science. With a residential college system and unmatched financial aid, Yale offers an intimate Ivy experience with global impact.",majors:["Law","Drama","Political Science","Economics","History","Medicine","Architecture"],scholarships:["Yale Financial Aid","Fulbright"],roadmap:["Score 1500+ SAT","Top class rank with rigorous coursework","Pursue arts, debate, or community leadership","Authentic essays showing intellectual depth","Apply by November 1 (REA) or January 1 (RD)","Strong teacher and counselor recommendations"]},
  {id:10,name:"Princeton University",short:"Princeton",loc:"Princeton, USA",region:"usa",emoji:"🟠",rank:"#2 USA",acc:4.7,tuition:59710,sat:"1510-1570",gpa:"3.9+",type:"Ivy League",url:"https://princeton.edu",diff:96,tags:["Ivy League","Research","STEM"],desc:"Princeton is the only Ivy League university that requires a senior thesis from every undergraduate. Its commitment to undergraduate teaching, generous financial aid, and beautiful campus make it uniquely special.",majors:["Computer Science","Mathematics","Economics","Engineering","Public Policy","Physics","Sociology"],scholarships:["Princeton Financial Aid","Fulbright","NSF Fellowship"],roadmap:["Score 1510+ SAT","Exceptional academic record in most rigorous courses","Independent research or creative project","Compelling essays — 'Why Princeton' is critical","Apply by November 1 (REA) or January 1 (RD)","Senior thesis readiness is a real advantage"]},
  {id:11,name:"Columbia University",short:"Columbia",loc:"New York, USA",region:"usa",emoji:"🗽",rank:"#12 World",acc:3.9,tuition:65524,sat:"1510-1580",gpa:"3.9+",type:"Ivy League",url:"https://columbia.edu",diff:96,tags:["Ivy League","Urban","Journalism"],desc:"Located in the heart of Manhattan, Columbia combines Ivy League academics with the world's greatest city. Its Core Curriculum gives every student a shared intellectual foundation across literature, philosophy, and science.",majors:["Journalism","Computer Science","Economics","Pre-Med","Political Science","Engineering","Film"],scholarships:["Columbia Financial Aid","Fulbright","Columbia Scholarship"],roadmap:["Score 1510+ SAT","Strong Core Curriculum interest (literature, philosophy)","Essays showing NYC connection and intellectual curiosity","Journalism, writing, or research background valued","Apply by November 1 (REA) or January 1 (RD)","Demonstrated interest in Columbia's unique curriculum"]},
  {id:12,name:"Imperial College London",short:"Imperial",loc:"London, UK",region:"uk",emoji:"🔬",rank:"#6 UK",acc:14,tuition:35100,sat:"N/A",gpa:"A*AA",type:"Research University",url:"https://imperial.ac.uk",diff:88,tags:["STEM","UK","Medicine"],desc:"Imperial College London is Europe's top STEM specialist university. Located in South Kensington, it leads the world in science, engineering, medicine, and business — with exceptional industry connections throughout London.",majors:["Medicine","Engineering","Computer Science","Physics","Chemistry","Business","Mathematics"],scholarships:["Imperial Excellence Scholarship","Chevening","Commonwealth Scholarship"],roadmap:["Predicted A*AA in STEM A-Levels","UKCAT/BMAT for Medicine applicants","Submit UCAS by October 15 (Medicine) or January 25","Show passion for STEM through independent reading","Strong teacher reference in science subjects","Attend Imperial open days — highly recommended"]},
  {id:13,name:"University College London",short:"UCL",loc:"London, UK",region:"uk",emoji:"🏙",rank:"#9 World",acc:16,tuition:26200,sat:"N/A",gpa:"A*AA-ABB",type:"Research University",url:"https://ucl.ac.uk",diff:85,tags:["Research","UK","Arts"],desc:"UCL is London's leading multidisciplinary university, consistently ranked among the world's top 10. Its location in Bloomsbury — the intellectual heart of London — and radical, open-minded culture attracts students from 150 countries.",majors:["Law","Architecture","Economics","Medicine","Computer Science","Philosophy","Engineering"],scholarships:["UCL Global Engagement Scholarship","Chevening","Lester B. Pearson (Canada transfer)"],roadmap:["A-Level predictions of A*AA to AAB depending on course","Submit via UCAS by January 25","Personal statement focused on academic motivation","Some courses require interviews or portfolio","English: IELTS 7.0+ overall","Accept offer and confirm by May"]},
  {id:14,name:"Technical University of Munich",short:"TU Munich",loc:"Munich, Germany",region:"europe",emoji:"🇩🇪",rank:"#37 World",acc:8,tuition:258,sat:"N/A",gpa:"Top national grades",type:"Technical University",url:"https://tum.de",diff:80,tags:["STEM","Europe","Free Tuition"],desc:"TU Munich is Germany's top university and one of Europe's elite STEM institutions. With semester fees of just €258 and world-class programs in engineering and computer science, it offers extraordinary value for international students.",majors:["Computer Science","Engineering","Robotics","Physics","Architecture","Mathematics","Business"],scholarships:["DAAD Scholarship","Deutschland Stipendium","Erasmus+"],roadmap:["Excellent secondary school grades in STEM","German language B2+ for German-taught programs (English for many MSc)","Apply via uni-assist or directly by January 15","Motivation letter required for Master's","Some programs have numerus clausus (NC) restrictions","Student visa required for non-EU students"]},
  {id:15,name:"University of Amsterdam",short:"UvA",loc:"Amsterdam, Netherlands",region:"europe",emoji:"🌷",rank:"#55 World",acc:35,tuition:2530,sat:"N/A",gpa:"Strong secondary results",type:"Research University",url:"https://uva.nl",diff:60,tags:["Europe","Liberal Arts","Affordable"],desc:"The University of Amsterdam is the Netherlands' largest university, known for its liberal academic climate and beautiful canal-side campus. With over 150 English-taught programs and low tuition fees, it's a top destination for international students.",majors:["Economics","Political Science","Psychology","Law","Computer Science","Media Studies","Communication"],scholarships:["Amsterdam Merit Scholarship","Holland Scholarship","Erasmus+"],roadmap:["Good secondary school grades (grade equivalent to Dutch VWO)","IELTS 6.5+ for English-taught programs","Apply via Studielink by May 1 (some programs earlier)","Some programs have selection or numerus fixus","Proof of financial means required for visa","Housing is competitive — apply early!"]},
  {id:16,name:"Peking University",short:"PKU",loc:"Beijing, China",region:"asia",emoji:"🐉",rank:"#17 World",acc:0.9,tuition:5200,sat:"N/A",gpa:"Top 1% nationally",type:"Research University",url:"https://pku.edu.cn",diff:99,tags:["Asia","Research","Prestigious"],desc:"Peking University is China's most prestigious university, the 'Harvard of China.' Its beautiful campus in Beijing houses Nobel laureates and has produced China's most influential leaders, scientists, and artists.",majors:["Law","Medicine","Economics","Computer Science","Philosophy","History","Physics"],scholarships:["Chinese Government Scholarship","Yenching Academy Scholarship","PKU International Scholarship"],roadmap:["For international students: apply via CSC scholarship","Top academic record in your country","Mandarin Chinese proficiency (HSK 5+) for most programs","English-taught programs available in some faculties","Submit application by March each year","Compelling personal statement in Chinese or English"]},
  {id:17,name:"McGill University",short:"McGill",loc:"Montreal, Canada",region:"canada",emoji:"🍦",rank:"#30 World",acc:38,tuition:22000,sat:"N/A",gpa:"3.7+",type:"Public Research",url:"https://mcgill.ca",diff:65,tags:["Canada","Research","Medicine"],desc:"McGill is Canada's oldest university and one of its most prestigious. Located in bilingual Montreal — one of the world's great student cities — it's known for medicine, law, and engineering, with a vibrant international community.",majors:["Medicine","Law","Engineering","Computer Science","Management","Psychology","Music"],scholarships:["Entrance Scholarship","McGill University Scholarship","Vanier CGS"],roadmap:["Strong secondary transcripts (top 10-15% of class)","IELTS 6.5+ for most programs","Apply via OUAC or directly by January 15","Some programs (Medicine, Law) have additional requirements","Scholarship application requires separate submission","Accept offer by May 1"]},
  {id:18,name:"Seoul National University",short:"SNU",loc:"Seoul, South Korea",region:"asia",emoji:"🇰🇷",rank:"#36 World",acc:12,tuition:5000,sat:"N/A",gpa:"Top national grades",type:"Public Research",url:"https://snu.ac.kr",diff:82,tags:["Asia","STEM","Affordable"],desc:"Seoul National University is South Korea's most prestigious university, renowned for its engineering, medicine, and business programs. Korea's tech boom — driven by Samsung, LG, and Hyundai — makes SNU graduates highly sought globally.",majors:["Engineering","Computer Science","Medicine","Business","Law","Natural Sciences","Social Sciences"],scholarships:["Korean Government Scholarship (KGSP)","SNU International Scholarship","Global Korea Scholarship"],roadmap:["Korean language TOPIK Level 3+ for Korean-taught programs","English-taught programs available in engineering and business","Apply via KGSP by March each year","Academic excellence record required","Statement of Purpose and 2 recommendations","Medical examination required for visa"]},
  {id:19,name:"Delft University of Technology",short:"TU Delft",loc:"Delft, Netherlands",region:"europe",emoji:"⚙",rank:"#47 World",acc:22,tuition:2530,sat:"N/A",gpa:"Strong STEM grades",type:"Technical University",url:"https://tudelft.nl",diff:72,tags:["Engineering","Europe","STEM"],desc:"TU Delft is Europe's largest and highest-ranked technical university. Known globally for aerospace, civil, and computer science engineering, it combines rigorous academics with a uniquely international and innovative culture.",majors:["Aerospace Engineering","Civil Engineering","Computer Science","Architecture","Electrical Engineering","Mechanical Engineering","Applied Mathematics"],scholarships:["Holland Scholarship","Justus & Louise van Effen Scholarship","Orange Tulip Scholarship","Erasmus+"],roadmap:["Strong mathematics and physics grades","IELTS 6.5+ or TOEFL 90+","Apply via Studielink by April 1","Motivation letter is critical — show passion for engineering","Some Master's programs are highly competitive","Campus housing: apply immediately after acceptance"]},
  {id:20,name:"University of Melbourne",short:"UniMelb",loc:"Melbourne, Australia",region:"australia",emoji:"🦘",rank:"#14 World",acc:70,tuition:35000,sat:"N/A",gpa:"3.5+",type:"Research University",url:"https://unimelb.edu.au",diff:55,tags:["Australia","Research","Liberal Arts"],desc:"The University of Melbourne is Australia's #1 university and consistently ranks in the world's top 20. Its Melbourne Model — a broad undergraduate degree followed by a specialist graduate degree — produces uniquely versatile graduates.",majors:["Law","Medicine","Engineering","Commerce","Arts","Science","Architecture"],scholarships:["Melbourne International Undergraduate Scholarship","Australia Awards","Endeavour Scholarship"],roadmap:["Strong secondary results (ATAR equivalent 85+)","IELTS 6.5-7.0+ depending on program","Apply via UAC or directly by October 30","Some programs (Medicine, Law) require UCAT or LSAT","Scholarship applications due by October 31","Student visa (subclass 500) required for international students"]},
  {id:8,name:"University of Cambridge",short:"Cambridge",loc:"Cambridge, UK",region:"uk",emoji:"🕊",rank:"#2 UK",acc:21,tuition:9535,sat:"A*A*A – A*AA",gpa:"A*A*A minimum",type:"Collegiate University",url:"https://cam.ac.uk",diff:93,tags:["Research","UK","Science"],desc:"Cambridge's exceptional faculty, research output, and rigorous intellectual culture attract the most outstanding students from around the world. Its supervisions offer unparalleled personalised teaching.",majors:["Natural Sciences","Mathematics","Engineering","Law","History","Economics","Computer Science"],scholarships:["Cambridge Trust","Gates Cambridge Scholarship","Prince Philip Scholarship"],roadmap:["Predicted A*A*A or A*AA in A-Levels","Apply via UCAS by October 15","Sit subject admissions test (NSAA, ENGAA, STEP, etc.)","Attend college interview in December","Conditional offer — meet final A-Level grade conditions","Confirm place and begin college placement in October"]},
];

const schs=[
  {id:1,name:"Rhodes Scholarship",provider:"Rhodes Trust",uni:"University of Oxford",amount:"Full tuition + £18,180/yr stipend",type:"full",field:"All fields",deadline:"October annually",url:"https://rhodeshouse.ox.ac.uk",desc:"The world's oldest and most prestigious international scholarship, founded in 1902. Rhodes funds 2–3 years of postgraduate study at Oxford for students who show exceptional academics, leadership, and commitment to service.",steps:["Check eligibility: citizenship, age 18–24, academic record","Gather transcripts and 4–6 letters of reference","Write personal statement on leadership, vision, and impact","Apply to national Rhodes committee in your country","Attend national selection committee interview","Winners notified Nov/Dec; Oxford enrollment the following October"],reqs:["First-class academic record","Demonstrated leadership capacity","Commitment to public service","Physical vigor and well-rounded character","Age 18–24 at October 1 of intake year"]},
  {id:2,name:"Gates Cambridge Scholarship",provider:"Gates Foundation",uni:"University of Cambridge",amount:"Full tuition + £18,840/yr living allowance",type:"full",field:"All fields",deadline:"October / December",url:"https://gatescambridge.org",desc:"Funded by Bill & Melinda Gates, Gates Cambridge awards ~80 full scholarships annually to outstanding postgraduate applicants from outside the UK who aim to make a positive difference in the world.",steps:["Apply to Cambridge postgraduate program via GRADSAF","Tick Gates Cambridge box on your application form","Shortlisted candidates interviewed January/February","Selection based on academics, leadership, and social impact","Offer made alongside Cambridge acceptance","Participate in annual Gates Cambridge Scholars events"],reqs:["Any citizenship outside the UK","Applying for full-time postgraduate degree at Cambridge","Outstanding academic achievement","Clear leadership potential","Commitment to improving the world"]},
  {id:3,name:"Fulbright U.S. Student Program",provider:"U.S. Dept. of State",uni:"Various US Universities",amount:"Full tuition + living allowance + flights",type:"full",field:"All fields",deadline:"October 12 annually",url:"https://fulbrightscholarships.gov",desc:"The US government's flagship global exchange program. Fulbright funds study, research, or teaching in the USA for students from 155+ countries, building mutual understanding between nations.",steps:["Contact your national Fulbright Commission for requirements","Attend an info session and gather application materials","Write a compelling study or research proposal","Obtain two strong academic references","Submit through your national Fulbright office by deadline","Finalists interview; winners receive J-1 visa sponsorship"],reqs:["Completed bachelor's degree","Strong academic record","English language proficiency","Compelling feasible study or research plan","National Fulbright endorsement required"]},
  {id:4,name:"Lester B. Pearson Scholarship",provider:"University of Toronto",uni:"University of Toronto",amount:"Full tuition + books + residence (4 years)",type:"full",field:"All fields",deadline:"November annually",url:"https://future.utoronto.ca/pearson",desc:"UofT's most prestigious international award. The Pearson recognizes exceptional achievement and creativity, and students who have made a real difference in their schools and communities.",steps:["Apply to University of Toronto by December 15","Be nominated by your secondary school (1 nomination/school)","Complete Pearson scholarship application in January","Application reviewed for academics, community, and leadership","Finalists may be contacted for additional information","Awards announced April; start at UofT the following September"],reqs:["Citizenship or permanent residence outside Canada","Entering UofT directly from secondary school","Exceptional academic achievement","Creative contribution to school and community","School nomination is mandatory"]},
  {id:5,name:"DAAD Scholarship",provider:"German Academic Exchange",uni:"German Universities",amount:"€850–€1,200/month + travel grant",type:"partial",field:"All fields",deadline:"Varies by program",url:"https://daad.de/en",desc:"One of the world's largest scholarship organizations, DAAD funds hundreds of programs for international students to study or research in Germany — a world-leading academic destination with mostly free tuition.",steps:["Search DAAD database for a program matching your field","Prepare language certificates (German or English required)","Write strong motivation letter and research proposal","Gather two academic references from professors","Submit online by your program's deadline","Selection takes 2–3 months; attend DAAD orientation if awarded"],reqs:["Above-average academic results","Relevant language proficiency","Clear study or research motivation","Some programs require 2 years work experience","Cannot receive other DAAD funding simultaneously"]},
,
  {id:7,name:"Chevening Scholarship",provider:"UK Government",uni:"Any UK University",amount:"Full tuition + £1,173/month living",type:"full",field:"All fields",deadline:"November annually",url:"https://chevening.org",desc:"Chevening is the UK government's flagship international scholarship, funded by the Foreign, Commonwealth and Development Office. It awards over 1,700 scholarships annually to outstanding individuals from around the world who demonstrate leadership potential.",steps:["Check eligibility: 2+ years work experience, citizenship in eligible country","Choose 3 UK universities and 1 course on your application","Write compelling essays on leadership, networking, and career goals","Obtain 2 professional references (not academic)","Submit online application by November deadline","Shortlisted candidates interviewed at British Embassy/High Commission in February-March","Offers made in June; courses begin September"],reqs:["Citizen of a Chevening-eligible country","Hold an undergraduate degree (minimum 2:2 / equivalent)","2+ years work experience","Return to home country for 2 years after scholarship","English proficiency: IELTS 6.5+","Demonstrate leadership and networking potential"]},
  {id:8,name:"Erasmus+ Scholarship",provider:"European Commission",uni:"EU Universities",amount:"€300-500/month + tuition waiver",type:"partial",field:"All fields",deadline:"Varies by institution",url:"https://erasmus-plus.ec.europa.eu",desc:"The Erasmus+ programme is the EU's flagship education and youth programme enabling students from 33 countries to study, train, and gain experience abroad. Over 3 million students have benefited since its founding in 1987.",steps:["Enroll at an Erasmus+ partner university in your country","Contact your international office to browse partner universities","Apply for nomination through your home institution","Complete application forms and language proficiency tests","Receive grant amount based on destination country cost of living","Study or train abroad for 3-12 months","Submit final report to receive full grant payment"],reqs:["Enrolled at an Erasmus+ partner institution","Complete at least 1 year of higher education before mobility","EU citizenship or residency at eligible institution","Basic language proficiency in host country language (or English)","Academic standing (grade threshold varies by institution)"]},
  {id:9,name:"Commonwealth Scholarship",provider:"Commonwealth Secretariat",uni:"UK Universities",amount:"Full tuition + living allowance + airfare",type:"full",field:"STEM, Health, Education",deadline:"October-December annually",url:"https://cscuk.fcdo.gov.uk",desc:"Commonwealth Scholarships enable talented and motivated people from Commonwealth countries to gain the skills and qualifications needed to become transformative leaders in their home countries. Over 25,000 scholars since 1960.",steps:["Check eligibility — must be Commonwealth citizen","Apply through your national nominating agency (not directly to CSC)","Prepare academic transcripts, CV, and 3 references","Write development impact statement: how will you help your country?","Nominated candidates assessed by Commonwealth Scholarship Commission","Offers made approximately May-June","Begin studies at UK university in September/October"],reqs:["Citizen of a Commonwealth country","Hold a first degree of at least upper second class (2:1)","Applying for postgraduate study","Demonstrate potential to benefit your home country","Commit to returning home after the scholarship","Cannot hold another major scholarship simultaneously"]},
  {id:10,name:"Australia Awards",provider:"Australian Government",uni:"Australian Universities",amount:"Full tuition + living allowance + airfare",type:"full",field:"All fields",deadline:"April-June annually",url:"https://australiaawards.gov.au",desc:"Australia Awards scholarships are prestigious international awards funded by the Australian government. They bring together people and ideas to promote development, build partnerships, and link individuals to Australia's aid program priorities.",steps:["Confirm your country is an Australia Awards partner country","Contact Australian embassy in your country for application instructions","Complete online application with academic records and references","Write an essay on development impact and leadership goals","Shortlisted candidates may attend interviews","Successful applicants receive pre-departure briefing","Begin degree program at Australian university"],reqs:["Citizen of an Australia Awards partner country","Not hold Australian citizenship or permanent residency","Met admission requirements of the Australian institution","Demonstrate leadership potential","Commit to returning home after study","Work experience relevant to proposed study preferred"]},
  {id:11,name:"Holland Scholarship",provider:"Dutch Universities + Ministry",uni:"Dutch Universities",amount:"€5,000 first year grant",type:"partial",field:"All fields",deadline:"February-May annually",url:"https://hollandscholarship.nl",desc:"The Holland Scholarship is a scholarship programme for international students from outside the European Economic Area who want to do their bachelor's or master's at a Dutch university of applied sciences or research university.",steps:["Select a Dutch university offering your program","Check if the university participates in Holland Scholarship","Apply for admission to the university first","Submit Holland Scholarship application through university portal","Selection by university based on academic excellence","Scholarship announced alongside admission offer","€5,000 paid in first year of study"],reqs:["Not an EU/EEA citizen","Applying for bachelor's or master's at participating Dutch university","Not previously studied in the Netherlands","Academic excellence — usually top 10% of applicants","Start studies in September (not February intake)"]},
  {id:12,name:"GREAT Scholarships",provider:"British Council",uni:"UK Universities",amount:"£10,000 towards tuition",type:"partial",field:"All fields",deadline:"Varies by country and university",url:"https://study-uk.britishcouncil.org/scholarships",desc:"GREAT Scholarships are offered by the British Council and 70+ UK universities in partnership with the GREAT Britain Campaign. Over 300 scholarships are available annually for postgraduate study in the UK, in partnership with governments worldwide.",steps:["Check your country's GREAT Scholarship availability on British Council website","Review participating universities and eligible courses","Apply directly to the university for both admission and scholarship","Universities select scholars based on academic merit","Submit all required documents by specified deadline","Scholarship award confirmed with admission offer","Begin postgraduate study in UK"],reqs:["Citizen of a participating GREAT Scholarship country","Applying for postgraduate (master's) degree","Strong academic background","Demonstrate why UK study and this specific university","English proficiency requirements vary by institution"]},
  {id:13,name:"Orange Tulip Scholarship",provider:"Nuffic Neso",uni:"Dutch Universities",amount:"25-100% tuition reduction",type:"partial",field:"All fields",deadline:"February-April annually",url:"https://studyinholland.nl/scholarships",desc:"The Orange Tulip Scholarship (OTS) is offered by the Dutch government through Nuffic in partnership with Dutch universities. It is available for students from specific countries and provides significant tuition fee reductions at participating universities.",steps:["Check if your country is eligible for OTS","Browse participating universities and programs on studyinholland.nl","Apply for admission to your chosen Dutch university","Request Orange Tulip Scholarship on your application form","University selects scholars based on academic merit","Scholarship percentage varies by university and program","Combine with Holland Scholarship for maximum funding"],reqs:["Citizen of eligible country (China, India, Brazil, South Korea, Vietnam, etc.)","Applying for bachelor's or master's program","Strong academic record","Not an EU/EEA citizen","Specific criteria vary by university"]},
  {id:14,name:"Yenching Academy Scholarship",provider:"Peking University",uni:"Peking University, China",amount:"Full tuition + stipend + accommodation",type:"full",field:"China Studies, Interdisciplinary",deadline:"January annually",url:"https://yenchingacademy.pku.edu.cn",desc:"The Yenching Academy of Peking University offers a unique one-year master's program in China Studies for exceptional graduates worldwide. Fully funded, it builds a global community of future leaders committed to cross-cultural understanding.",steps:["Apply online at Yenching Academy website by January deadline","Submit academic transcripts and 2 academic recommendations","Write essays on global challenges and cross-cultural leadership","Shortlisted applicants attend video interview in February-March","Final decisions announced in April","Pre-program orientation in Beijing in August","One-year master's program at Peking University begins September"],reqs:["Hold a bachelor's degree (or be in final year)","Under 30 years of age","Demonstrate academic excellence and leadership","Interest in China and cross-cultural engagement","Any nationality welcome — diversity is prioritised","No prior Chinese language required (program in English/Chinese options"]},
  {id:6,name:"Knight-Hennessy Scholars",provider:"Stanford University",uni:"Stanford University",amount:"Full tuition + $90,000+/yr stipend",type:"full",field:"All fields",deadline:"October annually",url:"https://knight-hennessy.stanford.edu",desc:"The largest fully-endowed scholarship in the world. Knight-Hennessy funds graduate study at Stanford for future global leaders who will address the world's greatest challenges with collaboration and innovation.",steps:["Apply to any Stanford graduate or professional program","Submit Knight-Hennessy application by October deadline","Complete video responses and essays on leadership and goals","Finalist interviews held at Stanford in March","Scholars announced in April","Participate in King Global Leadership Program during degree"],reqs:["Applying to any Stanford graduate or professional program","Demonstrated leadership across communities","Intention to work on world's greatest challenges","Strong academic record in all prior studies","Civic mindedness and collaborative spirit"]},
];

const vids=[
  {id:1,title:"How I Got Into Harvard — Full Journey & Tips",ch:"Emily Chen",dur:"18:42",tags:["Harvard","USA","Ivy"],advice:["Start essays in junior year summer — never rush them","Pursue one passion deeply rather than many shallowly","Show authentic curiosity — admissions officers read thousands of essays","GPA matters less than your story and how you tell it","Visit campus if you can and mention it meaningfully in essays"]},
  {id:2,title:"Full Ride Rhodes Scholarship — My Oxford Story",ch:"James Adeyemi",dur:"24:15",tags:["Oxford","Rhodes","UK"],advice:["Rhodes wants leaders, not just top students — prove both","Write about real impact, not just a list of achievements","The interview is an intellectual debate — enjoy it, don't fear it","Volunteer leadership is as important as academic record","Apply early and get multiple rounds of essay feedback"]},
  {id:3,title:"MIT Admission: What They DON'T Tell You",ch:"Priya Venkat",dur:"21:33",tags:["MIT","STEM","USA"],advice:["MIT looks for 'mind and hand' — builders, not just high scorers","Your research project is the most powerful asset in your application","Be hyper-specific about WHY MIT in your essays — generic won't cut it","Show intellectual passion through what you've actually built","A professor connection can significantly strengthen your application"]},
  {id:4,title:"Cambridge vs Oxford: I Applied to Both",ch:"Tom Whitfield",dur:"31:07",tags:["Oxford","Cambridge","UK"],advice:["Choose based on subject culture and teaching style, not just name","Oxbridge interviews aren't scary — read widely in your subject first","Personal statement must be 100% academic — no unrelated hobbies","Your subject teacher's reference is the single most important document","Attend open days — you'll feel immediately which one fits you"]},
  {id:5,title:"Stanford '27: How I Got Off the Waitlist",ch:"Sofia Reyes",dur:"14:28",tags:["Stanford","USA","Waitlist"],advice:["Letter of Continued Interest must add genuinely new information","Update with significant awards, publications, or projects only","Demonstrate continued interest early — attend events if possible","Don't give up — Stanford's waitlist does move significantly","Stanford values passion projects and entrepreneurship above grades"]},
  {id:6,title:"Fulbright Scholarship — Step by Step Guide",ch:"Kenji Tanaka",dur:"27:19",tags:["Fulbright","Scholarship","USA"],advice:["Start preparing 6+ months before the national deadline","Your proposal must address a specific real problem — not vague goals","References should know your research specifically, not just you","English writing quality matters enormously — use multiple editors","Apply even if you doubt yourself — Fulbright values diverse backgrounds"]},
];

// ── RENDER ──
function renderUnis(data){
  const g=document.getElementById('uni-grid');if(!g)return;
  const t=T();
  g.innerHTML=data.map(u=>`<div class="u-card" onclick="openUni(${u.id})">
    <div class="card-top"><div class="card-emoji">${u.emoji}</div><div><div class="card-top-name">${u.name}</div><div class="card-top-loc">${u.loc} • ${u.rank}</div></div></div>
    <div class="card-bd">
      <div class="card-pills">${u.tags.map(tg=>`<span class="pill p-blue">${tg}</span>`).join('')}<span class="pill ${u.acc<10?'p-red':u.acc<25?'p-amber':'p-green'}">${u.acc}% ${t.acc||'acc.'}</span></div>
      <div class="card-meta"><div class="c-meta">SAT <strong>${u.sat}</strong></div><div class="c-meta">GPA <strong>${u.gpa}</strong></div></div>
      <div class="card-ft"><span class="card-lnk">${t.card_view||'View profile →'}</span><span style="color:var(--g300)">→</span></div>
    </div></div>`).join('');
}

function renderSchs(data){
  const g=document.getElementById('sch-grid');if(!g)return;
  const t=T();
  g.innerHTML=data.map(s=>`<div class="s-card" onclick="openSch(${s.id})">
    <div class="card-top" style="background:linear-gradient(135deg,#111827,#1e3a8a)"><div class="card-emoji">🏆</div><div><div class="card-top-name">${s.name}</div><div class="card-top-loc">${s.provider}</div></div></div>
    <div class="card-bd">
      <div class="card-pills"><span class="pill ${s.type==='full'?'p-green':'p-blue'}">${s.type==='full'?(t.f_full||'Full Ride'):(t.f_partial||'Partial')}</span><span class="pill p-amber">${t.card_dl||'Deadline:'} ${s.deadline}</span></div>
      <div class="card-meta"><div class="c-meta"><strong>${s.amount}</strong></div></div>
      <div class="card-ft"><span class="card-lnk">${t.card_apply||'How to apply →'}</span><span style="color:var(--g300)">→</span></div>
    </div></div>`).join('');
}

function renderVids(){
  const g=document.getElementById('vid-grid');if(!g)return;
  const t=T();
  g.innerHTML=vids.map(v=>`<div class="vid-card" onclick="openVid(${v.id})">
    <div class="vid-thumb"><div class="play-btn">▶</div><div class="vid-dur">${v.dur}</div></div>
    <div class="vid-info">
      <div class="vid-title">${v.title}</div>
      <div class="vid-meta">${t.by||'by'} ${v.ch}</div>
      <div class="vid-pills">${v.tags.map(tg=>`<span class="pill p-blue">${tg}</span>`).join('')}</div>
    </div></div>`).join('');
}

// ── FILTERS ──
let aReg='all',aSchType='all';
function filterUnis(){const q=document.getElementById('uni-search').value.toLowerCase();renderUnis(unis.filter(u=>(aReg==='all'||u.region===aReg)&&(!q||u.name.toLowerCase().includes(q)||u.loc.toLowerCase().includes(q))));}
function filterRegion(r,b){aReg=r;document.querySelectorAll('#page-universities .f-chip').forEach(x=>x.classList.remove('active'));b.classList.add('active');filterUnis();}
function filterSchs(){const q=document.getElementById('sch-search').value.toLowerCase();renderSchs(schs.filter(s=>(aSchType==='all'||s.type===aSchType)&&(!q||s.name.toLowerCase().includes(q)||s.provider.toLowerCase().includes(q))));}
function filterSchType(tp,b){aSchType=tp;document.querySelectorAll('#page-scholarships .f-chip').forEach(x=>x.classList.remove('active'));b.classList.add('active');filterSchs();}

// ── MODALS ──
function openM(id){document.getElementById(id).classList.add('open');}
function closeM(id){document.getElementById(id).classList.remove('open');}
document.addEventListener('keydown',e=>{if(e.key==='Escape'){['uni-ov','sch-ov','vid-ov'].forEach(closeM);closeAuth();}});
document.querySelectorAll('.m-ov,.vm-ov').forEach(o=>o.addEventListener('click',e=>{if(e.target===o)closeM(o.id);}));

function openUni(id){
  const u=unis.find(x=>x.id===id);if(!u)return;
  const t=T();
  document.getElementById('mUN').textContent=u.name;
  document.getElementById('mUL').textContent=`${u.loc} • ${u.type}`;
  document.getElementById('mUB').innerHTML=`<span class="m-badge">${u.rank}</span><span class="m-badge">${u.type}</span>`;
  const dc=u.diff>=90?'#dc2626':u.diff>=70?'#d97706':'#16a34a';
  const dl=u.diff>=90?(t.diff_ext||'Extremely Selective'):u.diff>=70?(t.diff_very||'Very Selective'):(t.diff_sel||'Selective');
  document.getElementById('uni-mbody').innerHTML=`
    <div class="stats-row">
      <div class="s-box"><div class="s-box-val">${u.acc}%</div><div class="s-box-key">${t.mod_acc||'Acceptance Rate'}</div></div>
      <div class="s-box"><div class="s-box-val">$${u.tuition.toLocaleString()}</div><div class="s-box-key">${t.mod_tui||'Annual Tuition'}</div></div>
      <div class="s-box"><div class="s-box-val" style="font-size:1.1rem">${u.sat}</div><div class="s-box-key">${t.mod_sat||'SAT Range'}</div></div>
    </div>
    <div class="diff-wrap"><div class="diff-lbls"><span>${t.mod_diff||'Difficulty'}</span><span style="color:${dc};font-weight:700">${dl} (${u.diff}/100)</span></div><div class="diff-track"><div class="diff-fill" style="width:${u.diff}%"></div></div></div>
    <p class="m-desc">${u.desc}</p>
    <div class="m-sec">📚 ${t.mod_majors||'Popular Majors'}</div>
    <div class="chips-row">${u.majors.slice(0,6).map(m=>`<span class="chip">${m}</span>`).join('')}</div>
    <div class="m-sec">📋 ${t.mod_road||'Application Roadmap'}</div>
    <div class="roadmap">${u.roadmap.map((s,i)=>`<div class="rm-item"><div class="rm-left"><div class="rm-circle">${i+1}</div>${i<u.roadmap.length-1?'<div class="rm-line"></div>':''}</div><div class="rm-text">${s}</div></div>`).join('')}</div>
    <div class="m-sec">🎓 ${t.mod_schs||'Available Scholarships'}</div>
    <div class="sch-list">${u.scholarships.map(sn=>{const sc=schs.find(x=>x.name===sn);return`<div class="sch-row" onclick="${sc?`closeM('uni-ov');openSch(${sc.id})`:''}"><div><div class="sch-rname">${sn}</div><div class="sch-ramt">${sc?sc.amount:'—'}</div></div><span>→</span></div>`}).join('')}</div>
    <a href="${u.url}" target="_blank" class="visit-lnk">${t.mod_visit||'Visit university website'} ↗</a>`;
  openM('uni-ov');
}

function openSch(id){
  const s=schs.find(x=>x.id===id);if(!s)return;
  const t=T();
  document.getElementById('mSN').textContent=s.name;
  document.getElementById('mSS').textContent=`${s.provider} • ${s.uni}`;
  document.getElementById('mSA').innerHTML=`<span class="amt-pill">${s.amount}</span>`;
  document.getElementById('sch-mbody').innerHTML=`
    <p class="m-desc">${s.desc}</p>
    <div class="m-sec">✅ ${t.mod_elig||'Eligibility'}</div>
    <ul class="checklist">${s.reqs.map(r=>`<li>${r}</li>`).join('')}</ul>
    <div class="m-sec" style="margin-top:1.3rem">📋 ${t.mod_howto||'How to Apply'}</div>
    <div class="apply-steps">${s.steps.map((st,i)=>`<div class="a-step"><div class="a-circle">${i+1}</div><div class="a-text">${st}</div></div>`).join('')}</div>
    <div class="dl-box" style="margin-top:1.2rem"><strong>${t.mod_dl||'⏰ Deadline:'}</strong> <span style="color:var(--red)">${s.deadline}</span><br><strong>${t.mod_field||'📚 Field:'}</strong> ${s.field}</div>
    <a href="${s.url}" target="_blank" class="visit-lnk">${t.mod_svis||'Official scholarship website'} ↗</a>`;
  openM('sch-ov');
}

function openVid(id){
  const v=vids.find(x=>x.id===id);if(!v)return;
  const t=T();
  document.getElementById('vTitle').textContent=v.title;
  document.getElementById('vEmbed').innerHTML=`<div style="font-size:2.2rem;margin-bottom:.65rem">▶️</div><p style="color:rgba(255,255,255,.45);font-size:.84rem;margin-bottom:.9rem">"${v.title}"</p><a href="https://youtube.com/results?search_query=${encodeURIComponent(v.title)}" target="_blank" class="yt-lnk">▶ ${t.mod_watch||'Watch on YouTube'}</a>`;
  document.getElementById('vBody').innerHTML=`<div style="color:rgba(255,255,255,.35);font-size:.75rem;margin-bottom:.7rem">${t.by||'by'} ${v.ch} • ${v.dur}</div><div class="adv-title">${t.mod_adv||'💡 Key Advice'}</div>${v.advice.map(a=>`<div class="adv-item">${a}</div>`).join('')}`;
  openM('vid-ov');
}

// ── PAGE NAV ──
function showPage(name){
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
  document.getElementById('page-'+name).classList.add('active');
  document.querySelectorAll('.nl-btn').forEach(b=>b.classList.remove('active'));
  document.getElementById('nav-'+name)?.classList.add('active');
  window.scrollTo({top:0,behavior:'smooth'});
  if(name==='universities')renderUnis(unis);
  if(name==='scholarships')renderSchs(schs);
  if(name==='interviews')renderVids();
}
function scrollToChat(){showPage('home');setTimeout(()=>document.getElementById('chat-sec')?.scrollIntoView({behavior:'smooth'}),120);}
function toggleFaq(el){el.classList.toggle('open');}

// ── AUTH ──
let currentUser=JSON.parse(localStorage.getItem('cu')||'null');
const getDB=()=>JSON.parse(localStorage.getItem('cdb')||'{}');
const saveDB=db=>localStorage.setItem('cdb',JSON.stringify(db));

function openAuth(tab){document.getElementById('authOv').classList.add('open');switchTab(tab||'login');clearErrs();}
function closeAuth(){document.getElementById('authOv').classList.remove('open');}
function switchTab(tab){['login','register','forgot'].forEach(t=>{document.getElementById('tab-'+t)?.classList.remove('active');document.getElementById('panel-'+t).classList.remove('active');});document.getElementById('tab-'+tab)?.classList.add('active');document.getElementById('panel-'+tab).classList.add('active');}
function clearErrs(){document.querySelectorAll('.auth-err').forEach(e=>{e.classList.remove('show');e.textContent='';});}
function showErr(id,msg){const e=document.getElementById(id);e.textContent=msg;e.classList.add('show');}

function doLogin(){
  clearErrs();
  const em=document.getElementById('lEmail').value.trim(),pw=document.getElementById('lPass').value;
  if(!em||!pw){showErr('loginErr','Please fill in all fields.');return;}
  const db=getDB(),u=db[em];
  if(!u){showErr('loginErr','No account with this email.');return;}
  if(u.pw!==btoa(pw)){showErr('loginErr','Incorrect password.');return;}
  loginOK(u);
}
function doRegister(){
  clearErrs();
  const fn=document.getElementById('rFirst').value.trim(),ln=document.getElementById('rLast').value.trim(),em=document.getElementById('rEmail').value.trim(),pw=document.getElementById('rPass').value;
  if(!fn||!ln||!em||!pw){showErr('regErr','Please fill in all fields.');return;}
  if(pw.length<6){showErr('regErr','Password must be 6+ characters.');return;}
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em)){showErr('regErr','Invalid email address.');return;}
  const db=getDB();if(db[em]){showErr('regErr','Account already exists.');return;}
  const u={fn,ln,em,pw:btoa(pw)};db[em]=u;saveDB(db);loginOK(u);
}
function doForgot(){
  const em=document.getElementById('fEmail').value.trim();if(!em)return;
  document.getElementById('panel-forgot').innerHTML=`<div class="auth-ok">✅ Reset link sent to <strong>${em}</strong>.</div><p class="auth-note" style="margin-top:1rem"><a onclick="switchTab('login')">← Back to sign in</a></p>`;
}
function doGoogle(){const u={fn:'Google',ln:'User',em:'google@chetta.app',pw:''};const db=getDB();db[u.em]=u;saveDB(db);loginOK(u);}
function loginOK(u){currentUser=u;localStorage.setItem('cu',JSON.stringify(u));closeAuth();updateNav();}
function signOut(){currentUser=null;localStorage.removeItem('cu');document.getElementById('navUser').classList.remove('open');updateNav();}
function updateNav(){
  if(currentUser){
    document.getElementById('authBtns').style.display='none';
    const nu=document.getElementById('navUser');nu.style.display='flex';
    document.getElementById('navAv').textContent=(currentUser.fn[0]+(currentUser.ln?.[0]||'')).toUpperCase();
    document.getElementById('navUName').textContent=currentUser.fn;
    document.getElementById('ddName').textContent=currentUser.fn+' '+(currentUser.ln||'');
    document.getElementById('ddEmail').textContent=currentUser.em;
  }else{document.getElementById('authBtns').style.display='flex';document.getElementById('navUser').style.display='none';}
}
function toggleUMenu(){document.getElementById('navUser').classList.toggle('open');}
document.getElementById('authOv').addEventListener('click',e=>{if(e.target===document.getElementById('authOv'))closeAuth();});

// ── GEMINI AI ──
let chatHist=[],gemKey=localStorage.getItem('gk')||'';
const SYS=`You are Chetta AI, an expert university admissions advisor. You help students worldwide get into top universities. Deep knowledge of: Ivy League and top US universities; UK (Oxford/Cambridge/UCL/Imperial); Canadian, European, Asian universities; scholarships (Rhodes, Gates Cambridge, Fulbright, Chevening, DAAD, Erasmus, Pearson, Knight-Hennessy); SAT, ACT, IELTS, TOEFL prep; college essays, personal statements; financial aid, visa applications, timelines; acceptance rates, requirements, and strategies. Be concise, practical, warm, encouraging. Use bullet points for steps. Always offer to go deeper. Reply in the SAME LANGUAGE the user writes in (English, Uzbek, or Russian).`;

async function callGemini(msg){
  if(!gemKey){showKeyPrompt();return null;}
  const contents=[...chatHist.map(h=>({role:h.r,parts:[{text:h.t}]})),{role:'user',parts:[{text:msg}]}];
  const res=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${gemKey}`,{
    method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({system_instruction:{parts:[{text:SYS}]},contents,generationConfig:{temperature:.82,maxOutputTokens:650}})
  });
  if(!res.ok){const e=await res.json().catch(()=>({}));throw new Error(e?.error?.message||`Error ${res.status}`);}
  const d=await res.json();
  const reply=d?.candidates?.[0]?.content?.parts?.[0]?.text;
  if(!reply)throw new Error('Empty response');
  chatHist.push({r:'user',t:msg},{r:'model',t:reply});
  if(chatHist.length>20)chatHist=chatHist.slice(-20);
  return reply;
}

function showKeyPrompt(){
  const m=document.getElementById('chat-msgs');if(!m)return;
  document.getElementById('api-key-prompt')?.remove();
  const el=document.createElement('div');el.id='api-key-prompt';
  el.innerHTML=`<div style="font-weight:700;font-size:.875rem;color:var(--blue);margin-bottom:.35rem">🔑 Connect Gemini AI</div>
    <p>Get a free API key at <a href="https://aistudio.google.com/app/apikey" target="_blank" style="color:var(--blue)">aistudio.google.com</a> — it takes under 1 minute.</p>
    <div class="krow"><input type="password" id="gki" placeholder="AIza..." onkeydown="if(event.key==='Enter')saveKey()"><button onclick="saveKey()">Connect</button></div>
    <div class="knote">Stored only in your browser. Never shared.</div>`;
  m.appendChild(el);m.scrollTop=m.scrollHeight;
  setTimeout(()=>document.getElementById('gki')?.focus(),80);
}

function saveKey(){
  const v=document.getElementById('gki')?.value?.trim();
  if(!v||!v.startsWith('AIza'))return;
  gemKey=v;localStorage.setItem('gk',v);
  const p=document.getElementById('api-key-prompt');
  if(p){p.innerHTML='<div style="color:var(--green);font-weight:600;text-align:center;font-size:.84rem">✅ Gemini connected! Ask me anything.</div>';setTimeout(()=>p.remove(),2000);}
}
function disconnectKey(){gemKey='';localStorage.removeItem('gk');chatHist=[];}

async function sendMsg(custom){
  const inp=document.getElementById('chat-inp');
  const msg=custom||(inp?.value?.trim());if(!msg)return;
  if(inp)inp.value='';
  document.getElementById('api-key-prompt')?.remove();
  const m=document.getElementById('chat-msgs');if(!m)return;
  if(inp)inp.disabled=true;
  const sb=document.querySelector('.chat-send');if(sb)sb.disabled=true;
  const t=T();
  const youLbl=currentLang==='uz'?'Siz':currentLang==='ru'?'Вы':'You';
  m.innerHTML+=`<div class="msg umsg"><div class="msg-av uav">${youLbl.slice(0,2)}</div><div class="msg-bub">${esc(msg)}</div></div>`;
  m.scrollTop=m.scrollHeight;
  const ty=document.createElement('div');ty.className='msg';ty.id='ty-ind';
  ty.innerHTML=`<div class="msg-av aav">✦</div><div class="msg-bub" style="display:flex;gap:4px;align-items:center"><span style="width:6px;height:6px;border-radius:50%;background:var(--blue);animation:typing 1.2s infinite;display:block"></span><span style="width:6px;height:6px;border-radius:50%;background:var(--blue);animation:typing 1.2s .2s infinite;display:block"></span><span style="width:6px;height:6px;border-radius:50%;background:var(--blue);animation:typing 1.2s .4s infinite;display:block"></span></div>`;
  m.appendChild(ty);m.scrollTop=m.scrollHeight;
  try{
    const r=await callGemini(msg);
    document.getElementById('ty-ind')?.remove();
    if(r){m.innerHTML+=`<div class="msg"><div class="msg-av aav">✦</div><div class="msg-bub">${fmt(r)}</div></div>`;m.scrollTop=m.scrollHeight;}
  }catch(err){
    document.getElementById('ty-ind')?.remove();
    const isKey=err.message.toLowerCase().includes('key')||err.message.includes('400')||err.message.includes('403');
    m.innerHTML+=`<div class="msg"><div class="msg-av aav">✦</div><div class="msg-bub" style="background:#fef2f2;border:1px solid #fecaca;color:var(--red)">⚠️ ${esc(err.message)}${isKey?'<br><br><button onclick="disconnectKey();showKeyPrompt()" style="background:var(--blue);border:none;color:#fff;padding:.32rem .78rem;border-radius:6px;cursor:pointer;font-size:.77rem;font-family:DM Sans,sans-serif">Re-enter API key</button>':''}</div></div>`;
    m.scrollTop=m.scrollHeight;
    if(isKey){gemKey='';localStorage.removeItem('gk');}
  }finally{if(inp){inp.disabled=false;inp.focus();}if(sb)sb.disabled=false;}
}

function esc(s){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
function fmt(text){
  text=text.replace(/\*\*(.*?)\*\*/g,'<strong>$1</strong>').replace(/\*(.*?)\*/g,'<em>$1</em>');
  const lines=text.split('\n');let inL=false,out=[];
  for(let ln of lines){ln=ln.trim();if(!ln){if(inL){out.push('</ul>');inL=false;}out.push('<br>');continue;}
    if(/^[-•]\s+/.test(ln)){if(!inL){out.push('<ul style="margin:.38rem 0 .38rem 1rem;list-style:disc">');inL=true;}out.push(`<li style="margin-bottom:.22rem">${ln.replace(/^[-•]\s+/,'')}</li>`);}
    else{if(inL){out.push('</ul>');inL=false;}out.push(`<span>${ln}</span><br>`);}}
  if(inL)out.push('</ul>');
  return out.join('').replace(/(<br>){3,}/g,'<br><br>');
}

// ── I18N ──
let currentLang=localStorage.getItem('cl')||'en';
const LANGS={
en:{nav_home:'Home',nav_universities:'Universities',nav_scholarships:'Scholarships',nav_interviews:'Interviews',nav_ai:'AI Advisor',nav_signin:'Sign in',nav_getstarted:'Get started',nav_practice:'SAT Prep',dd_signout:'Sign out',auth_tagline:'Your path to a top university',auth_signin:'Sign in',auth_create:'Create account',auth_email:'Email',auth_password:'Password',auth_forgot:'Forgot password?',auth_signin_btn:'Sign in',auth_or:'or',auth_google:'Continue with Google',auth_no_account:'No account?',auth_create_link:'Create one free',auth_firstname:'First name',auth_lastname:'Last name',auth_create_btn:'Create free account',auth_terms:'By signing up you agree to our Terms and Privacy Policy.',auth_forgot_desc:"Enter your email and we'll send a reset link.",auth_send_reset:'Send reset link',auth_back_login:'← Back to sign in',hero_eyebrow:'✦ AI-Powered Admissions Platform',hero_h1:'Get into your <em>dream university</em>.',hero_sub:'Chetta gives you the tools, data, and AI guidance to navigate the most competitive university admissions in the world.',hero_btn1:'Start for free',hero_btn2:'Try AI Advisor',strip_label:'Helping students get into',ps1:'Universities saved',ps2:'Scholarships matched',ps3:'SAT target score',ps4:'Next deadline',pc1_lbl:'Application Readiness',pc2_lbl:'Your Universities',steps_eye:'How it works',steps_title:'Three steps to your dream school.',steps_sub:'From first search to final submission — Chetta walks you through every step.',s1_title:'Explore universities',s1_desc:'Browse 500+ universities with acceptance rates, tuition, SAT requirements, and full application roadmaps.',s2_title:'Find your scholarships',s2_desc:'Discover $2B+ in scholarships matched to your profile, country, GPA, and field — with deadlines and guides.',s3_title:'Get AI-powered guidance',s3_desc:'Chat with Chetta AI for essay feedback, admissions strategy, SAT tips, and visa guidance — 24/7.',feat_eye:'Platform features',feat_title:'Everything in one place.',f1_title:'University Explorer',f1_desc:'500+ universities with rankings, acceptance rates, tuition, and requirements — filterable by country and field.',f2_title:'Scholarship Finder',f2_desc:'Discover Rhodes, Gates Cambridge, Fulbright and more — with step-by-step guides and eligibility checklists.',f3_title:'AI Admissions Advisor',f3_desc:'Gemini-powered AI for essays, SAT tips, visa questions, comparisons. Remembers your conversation.',f4_title:'Ivy League Interviews',f4_desc:'Real Harvard, MIT, and Oxford students explain how they got in — with key advice and YouTube links.',f5_title:'Application Roadmaps',f5_desc:"Every university profile includes a step-by-step checklist for that school's specific process.",f6_title:'Multilingual Support',f6_desc:"Full support in English, O'zbek, and Русский. Switch instantly. AI responds in your language too.",testi_eye:'Student stories',testi_title:'Real students. Real results.',t1_q:'"Chetta\'s AI helped me understand what MIT was looking for. I rewrote my essays three times — and I got in."',t2_q:'"I found a full-ride scholarship through Chetta I\'d never heard of. The guide made applying easy. It covered four full years."',t3_q:'"The interview videos showed me how Oxford students think. Watching them changed how I wrote my personal statement."',faq_title:'Common questions',faq1_q:'Is Chetta free to use?',faq1_a:"Yes! University search, scholarships, and AI chat are all free. The AI uses Gemini — get a free key from Google AI Studio.",faq2_q:'How does the AI Advisor work?',faq2_a:"It uses Google Gemini 2.0 Flash configured as a university admissions expert. It remembers your conversation and replies in your language.",faq3_q:'What countries does Chetta cover?',faq3_a:'USA, UK, Canada, Europe (Germany, Switzerland, Netherlands), and Asia. 40+ countries with scholarships globally.',faq4_q:'Available in Uzbek and Russian?',faq4_a:"Yes — switch instantly with the flag selector top-right. The AI also detects and replies in your language.",cta_title:'Join thousands of students on their way to the top.',cta_sub:'Free to start. No credit card required.',cta_btn1:'Get started free →',cta_btn2:'Browse Universities',upage_eye:'Explore',upage_title:'University Explorer',upage_sub:'Click any university for full details, acceptance rates, and scholarships.',btn_search:'Search',f_all:'All',f_full:'Full Ride',f_partial:'Partial',spage_eye:'Funding',spage_title:'Scholarship Finder',spage_sub:'Discover $2B+ in scholarships — click any to see eligibility, amounts, and how to apply. Showing 14 featured scholarships.',ipage_eye:'Stories',ipage_title:'Ivy League Interviews',ipage_sub:'Real students. Real strategies. Learn from those who got in.',acc:'acc.',card_view:'View profile →',card_apply:'How to apply →',f_full:'Full Ride',f_partial:'Partial',card_dl:'Deadline:',by:'by',mod_acc:'Acceptance Rate',mod_tui:'Annual Tuition',mod_sat:'SAT Range',mod_diff:'Difficulty to Get In',diff_ext:'Extremely Selective',diff_very:'Very Selective',diff_sel:'Selective',mod_majors:'Popular Majors',mod_road:'Application Roadmap',mod_schs:'Available Scholarships',mod_visit:'Visit university website',mod_elig:'Eligibility Requirements',mod_howto:'How to Apply — Step by Step',mod_dl:'⏰ Deadline:',mod_field:'📚 Field:',mod_svis:'Official scholarship website',mod_watch:'Watch on YouTube',mod_adv:'💡 Key Advice from this Interview',ai_title:'Your AI Admissions Advisor',ai_sub:'Ask anything — scholarships, essays, SAT tips, visa questions. Powered by Gemini 2.0.',ai_agent:'Chetta AI',ai_status:'Powered by Gemini 2.0',ai_welcome:"Hi! I'm Chetta AI. Ask me anything about getting into top universities — essays, scholarships, SAT prep, visa guidance, or comparing schools. What's your dream school? 🎓",c1:'How do I get into Harvard?',c2:'Find me scholarships',c3:'SAT improvement tips',c4:'Help with my essay',c5:'IELTS for Oxford',c6:'Student visa guide',chat_ph:'Ask me anything about admissions...',prac_eye:'Test Prep',prac_title:'Practice like it\'s the real thing.',prac_sub:'4000+ SAT and IELTS questions with AI explanations, timed tests, and analytics.',pb_qb_title:'Question Bank',pb_qb_desc:'Work through SAT questions at your own pace with AI explanations.',pb_qb_badge:'200+ questions',pb_math_title:'Math Practice',pb_math_desc:'Algebra, geometry, data analysis with step-by-step solutions.',pb_math_badge:'150+ questions',pb_test_title:'Full Practice Test',pb_test_desc:'Simulate the real Digital SAT — timed, scored, reviewed.',pb_test_badge:'98 questions',pb_rush_title:'Question Rush',pb_rush_desc:'30 seconds per question. Build speed and improve pacing.',pb_rush_badge:'Speed mode',pb_vocab_title:'Vocabulary',pb_vocab_desc:'Master 200 most-tested SAT words with flashcards.',pb_vocab_badge:'200 words',pb_plan_title:'Study Planner',pb_plan_desc:'Enter test date and target score for a personalised schedule.',pb_plan_badge:'Personalised',pb_diag_title:'Diagnostic Test',pb_diag_desc:'Find your projected SAT score and weak domains in 30 min.',pb_diag_badge:'30 min',pb_calc_title:'Score Calculator',pb_calc_desc:'Enter raw scores to see your SAT score and percentile.',pb_calc_badge:'Instant',ana_eye:'Your Progress',ana_title:'Know your weak spots.',vocab_sub:'Click any card to reveal the definition.',planner_sub:'Set your test date and target score to generate your plan.',plan_date:'SAT Test Date',plan_current:'Current Score',plan_target:'Target Score',plan_hrs:'Daily Study Hours',plan_generate:'Generate My Plan',calc_sub:'Move sliders to see your estimated SAT score and percentile.',calc_rw:'Reading and Writing',calc_math:'Math',calc_questions:'Questions',calc_estimated:'Estimated SAT Score',calc_percentile:'Percentile',ielts_title:'IELTS Band Estimator',ielts_listening:'Listening',ielts_reading:'Reading',ielts_overall:'Estimated Overall Band',qb_submit:'Check Answer',qb_next:'Next',qb_skip:'Skip',res_retry:'Try Again',res_back:'Back to Practice',rush_title:'Question Rush',rush_desc:'30 seconds per question. Answer as many as you can!',rush_start:'Start Rush',rush_again:'Play Again',rush_answered:'questions answered',ft_desc:'Helping ambitious students worldwide access top universities and life-changing scholarships through intelligent guidance.',ft_ex:'Explore',ft_res:'Resources',ft_co:'Company',ft_sat:'SAT Prep Guide',ft_ielts:'IELTS Tips',ft_essay:'Essay Templates',ft_visa:'Visa Guide',ft_about:'About Chetta',ft_blog:'Blog',ft_priv:'Privacy Policy',ft_contact:'Contact',ft_copy:'© 2025 Chetta. All rights reserved.',ft_love:'Made for ambitious students everywhere'},

uz:{nav_home:'Bosh sahifa',nav_universities:'Universitetlar',nav_scholarships:'Stipendiyalar',nav_interviews:'Intervyular',nav_ai:'AI Maslahatchi',nav_signin:'Kirish',nav_getstarted:'Boshlash',nav_practice:'SAT Tayyorgarlik',dd_signout:'Chiqish',auth_tagline:"Top universitetga yo'lingiz",auth_signin:'Kirish',auth_create:'Hisob yaratish',auth_email:'Email',auth_password:'Parol',auth_forgot:'Parolni unutdingizmi?',auth_signin_btn:'Kirish',auth_or:'yoki',auth_google:'Google orqali kirish',auth_no_account:"Hisobingiz yo'qmi?",auth_create_link:'Bepul yarating',auth_firstname:'Ism',auth_lastname:'Familiya',auth_create_btn:'Bepul hisob yaratish',auth_terms:"Ro'yxatdan o'tib Shartlar va Maxfiylik siyosatiga rozisiz.",auth_forgot_desc:'Emailingizni kiriting, tiklash havolasini yuboramiz.',auth_send_reset:'Havolani yuborish',auth_back_login:'← Kirishga qaytish',hero_eyebrow:'✦ AI-Quvvatli Qabul Platformasi',hero_h1:'<em>Orzu universitetingizga</em> kiring.',hero_sub:"Chetta sizga dunyoning eng tanlov universitetlariga qabul bo'lishda kerakli vositalar, ma'lumotlar va AI yo'riqnomasini beradi.",hero_btn1:'Bepul boshlash',hero_btn2:"AI Maslahatchi sinab ko'rish",strip_label:"Quyidagilarga o'quvchilar kirdi",ps1:'Saqlangan universitetlar',ps2:'Mos stipendiyalar',ps3:'SAT maqsad bali',ps4:'Keyingi muddat',pc1_lbl:'Ariza tayyorgarligi',pc2_lbl:'Sizning universitetlaringiz',steps_eye:'Qanday ishlaydi',steps_title:"Orzu maktabingizga uch qadam.",steps_sub:"Birinchi qidiruvdan yakuniy topshiriqgacha — Chetta har qadamda yo'l ko'rsatadi.",s1_title:"Universitetlarni o'rganing",s1_desc:"500+ universitetni qabul darajasi, to'lov, SAT talablari va to'liq ariza yo'l xaritalari bilan ko'ring.",s2_title:'Stipendiyalaringizni toping',s2_desc:"Profilingizga, mamlakatga, GPA va sohangizga mos $2 mlrd+ stipendiyalarni toping — muddatlar va qo'llanmalar bilan.",s3_title:"AI yo'riqnoma oling",s3_desc:"Esse, qabul strategiyasi, SAT va viza uchun Chetta AI bilan suhbatlashing — 7/24 O'zbek, Ingliz, Rus tillarida.",feat_eye:'Platforma imkoniyatlari',feat_title:'Hamma narsa bir joyda.',f1_title:"Universitet Izlovchi",f1_desc:"500+ universitetni reyting, qabul darajasi, to'lov va talablar bilan — mamlakat va soha bo'yicha filtrlab.",f2_title:'Stipendiya Izlovchi',f2_desc:"Rhodes, Gates Cambridge, Fulbright va boshqalarni toping — qadam-baqadam qo'llanmalar bilan.",f3_title:'AI Qabul Maslahatchisi',f3_desc:'Gemini-quvvatli AI: essalar, SAT maslahatlari, viza savollari, universitetlarni solishtirish. Suhbatni eslab qoladi.',f4_title:"Ivy League Intervyulari",f4_desc:"Harvard, MIT va Oksford talabalarining o'zlaridan qanday kirganliklarini eshiting.",f5_title:"Ariza Yo'l Xaritalari",f5_desc:"Har bir universitet profili o'sha maktabning o'ziga xos jarayoni uchun qadam-baqadam ro'yxat o'z ichiga oladi.",f6_title:"Ko'p tilli qo'llab-quvvatlash",f6_desc:"O'zbek, Ingliz va Rus tillarida to'liq qo'llab-quvvatlash. Bir zumda almashtiring. AI ham tilingizda javob beradi.",testi_eye:'Talabalar hikoyalari',testi_title:"Haqiqiy talabalar. Haqiqiy natijalar.",t1_q:'"Chetta AI menga MITning nima qidirganini tushunishda yordam berdi. Fikr-mulohazasi asosida essalarni uch marta yozdim — va qabul bo\'ldim."',t2_q:'"Chetta orqali hech eshitmagan to\'liq stipendiyamni topdim. Qadam-baqadam qo\'llanma ariza berishni osonlashtirdi. To\'rt yilni qopladi."',t3_q:'"Intervyu videolari Oksford talabalarining qanday fikrlovini ko\'rsatdi. Shaxsiy bayonnomamni butunlay o\'zgartirdim."',faq_title:"Tez-tez so'raladigan savollar",faq1_q:"Chetta bepulmi?",faq1_a:"Ha! Universitet qidiruvi, stipendiyalar va AI suhbat barchasi bepul. AI Gemini'dan foydalanadi — Google AI Studio'dan bepul kalit oling.",faq2_q:'AI Maslahatchi qanday ishlaydi?',faq2_a:"Google Gemini 2.0 Flash qabul maslahatchisi sifatida sozlangan. Suhbatingizni eslab qoladi va tilingizda javob beradi.",faq3_q:'Chetta qaysi mamlakatlarni qamrab oladi?',faq3_a:"AQSh, Britaniya, Kanada, Yevropa (Germaniya, Shveytsariya, Niderlandiya) va Osiyo. Butun dunyo bo'yicha 40+ mamlakat.",faq4_q:"O'zbek va Rus tillarida mavjudmi?",faq4_a:"Ha — yuqori o'ng burchakdagi bayroqdan bir zumda almashtiring. AI ham tilingizni aniqlab, shunga javob beradi.",cta_title:"Minlab talabalar bilan top universitetlarga yo'lda qo'shiling.",cta_sub:"Boshlash bepul. Kredit karta talab qilinmaydi.",cta_btn1:'Bepul boshlash →',cta_btn2:"Universitetlarni ko'rish",upage_eye:'Izlash',upage_title:"Universitet Izlovchi",upage_sub:"To'liq tafsilotlar va stipendiyalarni ko'rish uchun istalgan universitetni bosing.",btn_search:'Qidirish',f_all:'Barchasi',f_full:"To'liq stipendiya",f_partial:'Qisman',spage_eye:'Moliyalashtirish',spage_title:'Stipendiya Izlovchi',spage_sub:"$2 mlrd+ stipendiya — munosiblik va ariza qanday berish haqida ko'rish uchun bosing.",ipage_eye:'Hikoyalar',ipage_title:"Ivy League Intervyulari",ipage_sub:"Haqiqiy talabalar. Haqiqiy strategiyalar. Muvaffaq bo'lganlardan o'rganing.",acc:'qabul',card_view:"Profilni ko'rish →",card_apply:'Qanday ariza berish →',card_dl:'Muddat:',by:'',mod_acc:'Qabul darajasi',mod_tui:"Yillik o'quv to'lovi",mod_sat:'SAT diapazoni',mod_diff:'Kirish qiyinligi',diff_ext:"O'ta tanlovli",diff_very:'Juda tanlovli',diff_sel:'Tanlovli',mod_majors:"Mashhur ixtisosliklar",mod_road:"Ariza yo'l xaritasi",mod_schs:"Mavjud stipendiyalar",mod_visit:"Universitet saytiga o'tish",mod_elig:'Munosiblik talablari',mod_howto:'Qanday ariza berish — qadam-baqadam',mod_dl:'⏰ Muddat:',mod_field:"📚 Soha:",mod_svis:"Rasmiy stipendiya saytiga o'tish",mod_watch:"YouTube'da ko'rish",mod_adv:"💡 Intervyudan asosiy maslahatlar",ai_title:'Sizning AI Qabul Maslahatchangiz',ai_sub:"Istalganini so'rang — stipendiyalar, essalar, SAT, viza. Gemini 2.0 bilan ishlaydi.",ai_agent:'Chetta AI',ai_status:'Gemini 2.0 bilan ishlaydi',ai_welcome:"Salom! Men Chetta AI. Top universitetlarga kirish haqida istalgan narsani so'rang. Orzu universitetingiz qaysi? 🎓",c1:'Harvardga qanday kirish mumkin?',c2:'Menga stipendiya toping',c3:'SAT balini yaxshilash',c4:'Esse yozishda yordam',c5:"Oksford uchun IELTS",c6:"Talaba vizasi yo'riqnomasi",chat_ph:"Qabul haqida istalgan narsani so'rang...",prac_eye:'Test Tayyorgarligi',prac_title:'Haqiqiy imtihondek mashq qiling.',prac_sub:"4000+ SAT va IELTS savollari AI tushuntirishlari bilan.",pb_qb_title:'Savollar Banki',pb_qb_desc:"SAT savollarini o'z sur'atingizda ishlang.",pb_qb_badge:'200+ savol',pb_math_title:'Matematika',pb_math_desc:'Algebra va geometriya — qadam-baqadam yechimlar.',pb_math_badge:'150+ savol',pb_test_title:"To'liq Test",pb_test_desc:"Haqiqiy SATni simulyatsiya qiling.",pb_test_badge:'98 savol',pb_rush_title:'Savol Rush',pb_rush_desc:'Har savol uchun 30 soniya.',pb_rush_badge:'Tezlik',pb_vocab_title:"Lug'at",pb_vocab_desc:"SAT so'zlarini kartochkalar bilan o'rganing.",pb_vocab_badge:"200 so'z",pb_plan_title:"O'qish Rejasi",pb_plan_desc:'Test sanangizni kiriting — shaxsiy jadval oling.',pb_plan_badge:'Shaxsiy',pb_diag_title:'Diagnostik Test',pb_diag_desc:'30 daqiqada taxminiy balingizni toping.',pb_diag_badge:'30 daq',pb_calc_title:'Bal Kalkulyatori',pb_calc_desc:'Xom ballarni kiriting — natijani bir zumda koring.',pb_calc_badge:'Tezkor',ana_eye:'Taraqqiyotingiz',ana_title:"Zaif joylaringizni biling.",vocab_sub:"Izohni ko'rsatish uchun bosing.",planner_sub:'Test sanangizni va maqsad balingizni kiriting.',plan_date:'SAT Test Sanasi',plan_current:'Joriy Bal',plan_target:'Maqsad Bal',plan_hrs:"O'qish soatlari",plan_generate:'Reja Yaratish',calc_sub:'Slayderni torting.',calc_rw:"O'qish va Yozish",calc_math:'Matematika',calc_questions:'Savollar',calc_estimated:'Taxminiy SAT Bali',calc_percentile:'Foizli daraja',ielts_title:'IELTS Band Estimator',ielts_listening:'Tinglash',ielts_reading:"O'qish",ielts_overall:'Taxminiy Band',qb_submit:'Tekshirish',qb_next:'Keyingisi',qb_skip:"O'tkazish",res_retry:'Qayta urinish',res_back:'Orqaga',rush_title:'Savol Rush',rush_desc:'Har savol uchun 30 soniya!',rush_start:'Boshlash',rush_again:"Yana o'ynash",rush_answered:'savol javoblandi',ft_desc:"Chetta dunyo bo'ylab talabalariga top universitetlar va stipendiyalarga yordam beradi.",ft_ex:'Izlash',ft_res:'Resurslar',ft_co:'Kompaniya',ft_sat:"SAT Qo'llanmasi",ft_ielts:'IELTS Maslahatlari',ft_essay:'Esse Shablonlari',ft_visa:"Viza Qo'llanmasi",ft_about:'Chetta Haqida',ft_blog:'Blog',ft_priv:'Maxfiylik Siyosati',ft_contact:'Aloqa',ft_copy:"© 2025 Chetta. Barcha huquqlar himoyalangan.",ft_love:"Dunyo bo'yicha talabalar uchun yaratilgan"},

ru:{nav_home:'Главная',nav_universities:'Университеты',nav_scholarships:'Стипендии',nav_interviews:'Интервью',nav_ai:'ИИ Советник',nav_signin:'Войти',nav_getstarted:'Начать',nav_practice:'Подготовка к SAT',dd_signout:'Выйти',auth_tagline:'Ваш путь в топ-университет',auth_signin:'Войти',auth_create:'Создать аккаунт',auth_email:'Email',auth_password:'Пароль',auth_forgot:'Забыли пароль?',auth_signin_btn:'Войти',auth_or:'или',auth_google:'Войти через Google',auth_no_account:'Нет аккаунта?',auth_create_link:'Создайте бесплатно',auth_firstname:'Имя',auth_lastname:'Фамилия',auth_create_btn:'Создать бесплатный аккаунт',auth_terms:'Регистрируясь вы соглашаетесь с Условиями и Политикой конфиденциальности.',auth_forgot_desc:'Введите email, и мы отправим ссылку для сброса пароля.',auth_send_reset:'Отправить ссылку',auth_back_login:'← Назад к входу',hero_eyebrow:'✦ ИИ-платформа для поступления',hero_h1:'Поступите в <em>университет мечты</em>.',hero_sub:'Chetta даёт вам инструменты, данные и руководство ИИ для навигации в самых конкурентных университетских приёмных в мире.',hero_btn1:'Начать бесплатно',hero_btn2:'Попробовать ИИ Советник',strip_label:'Помогаем студентам поступить в',ps1:'Сохранённых университетов',ps2:'Подобранных стипендий',ps3:'Целевой балл SAT',ps4:'Следующий дедлайн',pc1_lbl:'Готовность заявки',pc2_lbl:'Ваши университеты',steps_eye:'Как это работает',steps_title:'Три шага до университета мечты.',steps_sub:'От первого поиска до финальной подачи — Chetta ведёт вас через каждый шаг.',s1_title:'Изучите университеты',s1_desc:'Просматривайте 500+ университетов с процентами поступления, стоимостью, SAT и полными дорожными картами заявки.',s2_title:'Найдите стипендии',s2_desc:'Откройте $2+ млрд стипендий, подобранных по профилю, стране, GPA и области — с дедлайнами и руководствами.',s3_title:'Получите ИИ-руководство',s3_desc:'Общайтесь с Chetta AI для отзывов на эссе, стратегии, советов по SAT и визовых вопросов — 24/7.',feat_eye:'Возможности платформы',feat_title:'Всё в одном месте.',f1_title:'Обзор Университетов',f1_desc:'500+ университетов с рейтингами, процентами поступления и требованиями — фильтрация по стране и области.',f2_title:'Поиск Стипендий',f2_desc:'Откройте Rhodes, Gates Cambridge, Fulbright и другие — с пошаговыми руководствами и чеклистами.',f3_title:'ИИ Советник',f3_desc:'Gemini-ИИ для эссе, SAT, визовых вопросов, сравнений. Запоминает разговор.',f4_title:'Интервью Ivy League',f4_desc:'Реальные студенты Гарварда, MIT и Оксфорда объясняют как поступили — с советами и ссылками на YouTube.',f5_title:'Дорожные карты заявки',f5_desc:'Каждый профиль включает пошаговый чеклист для конкретного процесса этой школы.',f6_title:'Многоязычная поддержка',f6_desc:'Полная поддержка на русском, английском и узбекском. Переключайте мгновенно. ИИ отвечает на вашем языке.',testi_eye:'Истории студентов',testi_title:'Реальные студенты. Реальные результаты.',t1_q:'"ИИ Chetta помог мне понять что искал MIT. Трижды переписал эссе на основе отзывов — и поступил."',t2_q:'"Нашёл полную стипендию через Chetta о которой никогда не слышал. Пошаговое руководство упростило всё. Покрыла четыре года."',t3_q:'"Видео с интервью показали как мыслят студенты Оксфорда. Это полностью изменило моё личное заявление."',faq_title:'Частые вопросы',faq1_q:'Chetta бесплатна?',faq1_a:'Да! Поиск университетов, стипендий и ИИ-чат бесплатны. ИИ использует Gemini — получите бесплатный ключ в Google AI Studio.',faq2_q:'Как работает ИИ Советник?',faq2_a:'Использует Google Gemini 2.0 Flash настроенный как эксперт по поступлению. Запоминает разговор и отвечает на вашем языке.',faq3_q:'Какие страны охватывает Chetta?',faq3_a:'США, Великобритания, Канада, Европа (Германия, Швейцария, Нидерланды) и Азия. 40+ стран со стипендиями глобально.',faq4_q:'Доступна на узбекском и русском?',faq4_a:'Да — переключайте мгновенно через флаг в правом верхнем углу. ИИ также определяет и отвечает на вашем языке.',cta_title:'Присоединяйтесь к тысячам студентов на пути к вершине.',cta_sub:'Бесплатный старт. Кредитная карта не нужна.',cta_btn1:'Начать бесплатно →',cta_btn2:'Смотреть университеты',upage_eye:'Обзор',upage_title:'Обзор Университетов',upage_sub:'Нажмите на любой университет для полных деталей, процента поступления и стипендий.',btn_search:'Поиск',f_all:'Все',f_full:'Полное финансирование',f_partial:'Частичное',spage_eye:'Финансирование',spage_title:'Поиск Стипендий',spage_sub:'$2+ млрд стипендий — нажмите на любую для критериев и как подать заявку.',ipage_eye:'Истории',ipage_title:'Интервью Ivy League',ipage_sub:'Реальные студенты. Реальные стратегии. Учитесь у поступивших.',acc:'поступление',card_view:'Смотреть профиль →',card_apply:'Как подать →',card_dl:'Дедлайн:',by:'',mod_acc:'Процент поступления',mod_tui:'Годовая стоимость',mod_sat:'Диапазон SAT',mod_diff:'Сложность поступления',diff_ext:'Крайне высокий конкурс',diff_very:'Очень высокий конкурс',diff_sel:'Высокий конкурс',mod_majors:'Популярные специальности',mod_road:'Дорожная карта заявки',mod_schs:'Доступные стипендии',mod_visit:'Перейти на сайт университета',mod_elig:'Требования участия',mod_howto:'Как подать — шаг за шагом',mod_dl:'⏰ Дедлайн:',mod_field:'📚 Область:',mod_svis:'Официальный сайт стипендии',mod_watch:'Смотреть на YouTube',mod_adv:'💡 Ключевые советы из интервью',ai_title:'Ваш ИИ Советник по поступлению',ai_sub:'Спрашивайте что угодно — стипендии, эссе, SAT, визовые вопросы. Работает на Gemini 2.0.',ai_agent:'Chetta AI',ai_status:'Работает на Gemini 2.0',ai_welcome:'Привет! Я Chetta AI. Спрашивайте что угодно о поступлении в топ-университеты. Какой ваш университет мечты? 🎓',c1:'Как поступить в Гарвард?',c2:'Найти стипендии',c3:'Советы по улучшению SAT',c4:'Помощь с эссе',c5:'IELTS для Оксфорда',c6:'Руководство по студенческой визе',chat_ph:'Спросите что угодно о поступлении...',prac_eye:'Подготовка',prac_title:'Практикуйтесь как на настоящем экзамене.',prac_sub:'4000+ вопросов SAT и IELTS с объяснениями ИИ и аналитикой.',pb_qb_title:'Банк вопросов',pb_qb_desc:'Решайте вопросы SAT в своём темпе с объяснениями ИИ.',pb_qb_badge:'200+ вопросов',pb_math_title:'Математика',pb_math_desc:'Алгебра и геометрия с пошаговыми решениями.',pb_math_badge:'150+ вопросов',pb_test_title:'Полный тест',pb_test_desc:'Симулируйте реальный SAT с таймером и разбором.',pb_test_badge:'98 вопросов',pb_rush_title:'Быстрые вопросы',pb_rush_desc:'30 секунд на вопрос. Развивайте скорость.',pb_rush_badge:'Скорость',pb_vocab_title:'Словарь',pb_vocab_desc:'200 слов SAT с карточками и примерами.',pb_vocab_badge:'200 слов',pb_plan_title:'План обучения',pb_plan_desc:'Введите дату теста для персонального расписания.',pb_plan_badge:'Персональный',pb_diag_title:'Диагностика',pb_diag_desc:'Узнайте прогноз балла SAT за 30 минут.',pb_diag_badge:'30 мин',pb_calc_title:'Калькулятор',pb_calc_desc:'Введите баллы — мгновенный результат.',pb_calc_badge:'Мгновенно',ana_eye:'Прогресс',ana_title:'Знайте свои слабые места.',vocab_sub:'Нажмите на карточку для определения.',planner_sub:'Введите дату теста и целевой балл.',plan_date:'Дата SAT',plan_current:'Текущий балл',plan_target:'Целевой балл',plan_hrs:'Часов в день',plan_generate:'Создать план',calc_sub:'Двигайте слайдеры для расчёта балла.',calc_rw:'Чтение и письмо',calc_math:'Математика',calc_questions:'Вопросы',calc_estimated:'Расчётный балл SAT',calc_percentile:'Перцентиль',ielts_title:'Оценщик IELTS',ielts_listening:'Аудирование',ielts_reading:'Чтение',ielts_overall:'Общий балл',qb_submit:'Проверить',qb_next:'Далее',qb_skip:'Пропустить',res_retry:'Ещё раз',res_back:'Назад',rush_title:'Быстрые вопросы',rush_desc:'30 секунд на вопрос!',rush_start:'Начать',rush_again:'Снова',rush_answered:'отвечено',ft_desc:'Chetta помогает амбициозным студентам по всему миру получить доступ к топ-университетам и стипендиям.',ft_ex:'Обзор',ft_res:'Ресурсы',ft_co:'Компания',ft_sat:'Руководство по SAT',ft_ielts:'Советы по IELTS',ft_essay:'Шаблоны эссе',ft_visa:'Визовое руководство',ft_about:'О Chetta',ft_blog:'Блог',ft_priv:'Конфиденциальность',ft_contact:'Контакт',ft_copy:'© 2025 Chetta. Все права защищены.',ft_love:'Создано для амбициозных студентов везде'},
};
const langMeta={en:{f:'🇬🇧',l:'ENG'},uz:{f:'🇺🇿',l:'UZ'},ru:{f:'🇷🇺',l:'RU'}};
const T=()=>LANGS[currentLang]||LANGS.en;

function applyLang(lang){
  currentLang=lang;localStorage.setItem('cl',lang);
  const t=T();
  document.querySelectorAll('[data-i18n]').forEach(el=>{const k=el.getAttribute('data-i18n');if(t[k]!==undefined)el.innerHTML=t[k];});
  document.getElementById('cflag').textContent=langMeta[lang].f;
  document.getElementById('clbl').textContent=langMeta[lang].l;
  ['en','uz','ru'].forEach(l=>{document.getElementById('lang-'+l)?.classList.toggle('sel',l===lang);});
  // placeholders
  const us=document.getElementById('uni-search');if(us)us.placeholder=lang==='uz'?"Universitet nomi yoki mamlakat...":lang==='ru'?'Поиск по названию или стране...':'Search by name or country...';
  const ss=document.getElementById('sch-search');if(ss)ss.placeholder=lang==='uz'?'Stipendiyalarni qidirish...':lang==='ru'?'Поиск стипендий...':'Search scholarships...';
  const ci=document.getElementById('chat-inp');if(ci)ci.placeholder=t.chat_ph||'Ask me anything...';
  // re-render visible cards
  if(document.getElementById('uni-grid')?.children.length)renderUnis(unis.filter(u=>aReg==='all'||u.region===aReg));
  if(document.getElementById('sch-grid')?.children.length)renderSchs(schs);
  if(document.getElementById('vid-grid')?.children.length)renderVids();
  // update chat static text
  const cn=document.querySelector('.chat-hd-name');if(cn)cn.textContent=t.ai_agent;
  const cs=document.querySelector('.chat-hd-status');if(cs)cs.innerHTML=`<span class="st-dot"></span>${t.ai_status}`;
  const chips=document.querySelectorAll('.p-chip');
  ['c1','c2','c3','c4','c5','c6'].forEach((k,i)=>{if(chips[i]&&t[k]){chips[i].textContent=t[k];chips[i].onclick=()=>sendMsg(t[k]);}});
  // rebuild footer
  buildFooter(t);
}

function buildFooter(t){
  const ft=document.querySelector('footer');if(!ft)return;
  ft.innerHTML=`<div class="ft-inner"><div class="ft-grid"><div><div class="ft-logo">Chetta<em>.</em></div><p class="ft-desc">${t.ft_desc}</p></div><div class="ft-col"><h4>${t.ft_ex}</h4><ul><li><a onclick="showPage('universities')">${t.nav_universities}</a></li><li><a onclick="showPage('scholarships')">${t.nav_scholarships}</a></li><li><a onclick="showPage('interviews')">${t.nav_interviews}</a></li><li><a onclick="scrollToChat()">${t.nav_ai}</a></li></ul></div><div class="ft-col"><h4>${t.ft_res}</h4><ul><li><a href="#">${t.ft_sat}</a></li><li><a href="#">${t.ft_ielts}</a></li><li><a href="#">${t.ft_essay}</a></li><li><a href="#">${t.ft_visa}</a></li></ul></div><div class="ft-col"><h4>${t.ft_co}</h4><ul><li><a href="#">${t.ft_about}</a></li><li><a href="#">${t.ft_blog}</a></li><li><a href="#">${t.ft_priv}</a></li><li><a href="#">${t.ft_contact}</a></li></ul></div></div><div class="ft-bottom"><span>${t.ft_copy}</span><span>${t.ft_love}</span></div></div>`;
}

function setLang(l){applyLang(l);document.getElementById('langSw').classList.remove('open');}
function toggleLangMenu(e){e.stopPropagation();document.getElementById('langSw').classList.toggle('open');}
document.addEventListener('click',e=>{if(!e.target.closest('#langSw'))document.getElementById('langSw').classList.remove('open');if(!e.target.closest('#navUser'))document.getElementById('navUser').classList.remove('open');});

// ── CHAT INJECT ──
const chatHTML=`<section class="chat-sec" id="chat-sec"><div class="chat-wrap"><div style="text-align:center;margin-bottom:.25rem"><div class="sec-eye" style="display:inline-block" data-i18n="feat_eye">Platform features</div><h2 class="sec-title" style="margin-top:.5rem" data-i18n="ai_title">Your AI Admissions Advisor</h2><p class="sec-sub" style="margin:0 auto" data-i18n="ai_sub">Ask anything — scholarships, essays, SAT tips, visa questions. Powered by Gemini 2.0.</p></div><div class="chat-win"><div class="chat-hd"><div class="chat-hd-l"><div class="chat-icon">✦AI</div><div><div class="chat-hd-name" data-i18n="ai_agent">Chetta AI</div><div class="chat-hd-status"><span class="st-dot"></span><span data-i18n="ai_status">Powered by Gemini 2.0</span></div></div></div><button class="chat-hd-btn" onclick="disconnectKey();showKeyPrompt()">🔑 API Key</button></div><div class="chat-msgs" id="chat-msgs"><div class="msg"><div class="msg-av aav">✦</div><div class="msg-bub" data-i18n="ai_welcome">Hi! I'm Chetta AI. Ask me anything about getting into top universities. What's your dream school? 🎓</div></div></div><div class="chat-prompts" id="chat-prompts"><button class="p-chip" onclick="sendMsg('How do I get into Harvard?')" data-i18n="c1">How do I get into Harvard?</button><button class="p-chip" onclick="sendMsg('Find me scholarships')" data-i18n="c2">Find me scholarships</button><button class="p-chip" onclick="sendMsg('SAT improvement tips')" data-i18n="c3">SAT improvement tips</button><button class="p-chip" onclick="sendMsg('Help with my essay')" data-i18n="c4">Help with my essay</button><button class="p-chip" onclick="sendMsg('IELTS for Oxford')" data-i18n="c5">IELTS for Oxford</button><button class="p-chip" onclick="sendMsg('Student visa guide')" data-i18n="c6">Student visa guide</button></div><div class="chat-inp-row"><input class="chat-inp" type="text" id="chat-inp" placeholder="Ask me anything about admissions..." onkeydown="if(event.key==='Enter')sendMsg()"><button class="chat-send" onclick="sendMsg()">↑</button></div></div></div></section>`;

document.querySelector('.testi-sec').insertAdjacentHTML('beforebegin',chatHTML);
document.getElementById('page-home').insertAdjacentHTML('beforeend','<footer></footer>');

// ── INIT ──
applyLang(currentLang);
updateNav();
setTimeout(()=>{if(!gemKey){const m=document.getElementById('chat-msgs');if(m)showKeyPrompt();}},650);


// ════════════════════════════════════════
// CHETTA PRACTICE MODULE
// Sources: Khan Academy SAT open data + original questions
// ════════════════════════════════════════

// ── QUESTION DATA (SAT-style, original/open source) ──
const QUESTIONS = {
reading: [
  {id:'r1',passage:`The development of agriculture transformed human societies in fundamental ways. Prior to farming, people lived as hunter-gatherers, moving frequently to follow seasonal food sources. Agriculture allowed permanent settlements to form, which in turn enabled the development of complex social structures, specialised labour, and eventually written language. However, some historians argue that the shift to farming also brought negative consequences, including increased social inequality and new diseases spread through dense populations.`,
   question:`Based on the passage, which best describes a consequence of agriculture that the author presents as potentially negative?`,
   options:['Permanent settlements replacing nomadic lifestyles','The development of written language','Increased social inequality in farming communities','Specialised labour replacing general survival skills'],
   answer:2,explanation:`The passage states that "some historians argue that the shift to farming also brought negative consequences, including increased social inequality." Choice C directly mirrors this. While A is mentioned, it is presented as a change, not a negative consequence.`},
  {id:'r2',passage:`Bioluminescence, the production of light by living organisms, occurs across a remarkable range of species. In the deep ocean, where sunlight cannot penetrate, organisms from bacteria to large fish have evolved this ability independently multiple times. Scientists believe bioluminescence serves several purposes: attracting prey, communicating with potential mates, and deterring predators through startling flashes of light.`,
   question:`The passage suggests that bioluminescence evolved independently "multiple times" primarily because:`,
   options:['It is a genetically simple trait easy to develop','Different species adapted to the same challenging environment','Scientists have studied deep-ocean life extensively','Light production is energetically inexpensive'],
   answer:1,explanation:`The passage notes bioluminescence evolved independently multiple times in the deep ocean where sunlight cannot penetrate — different organisms adapted to the same environmental challenge. This supports choice B.`},
  {id:'r3',passage:``,
   question:`Which choice completes the text with the most logical and precise word?
\n"The linguist's analysis was remarkably ______, covering not only grammar and syntax but also cultural context and historical etymology."`,
   options:['comprehensive','redundant','concise','ambiguous'],
   answer:0,explanation:`"Comprehensive" means covering all aspects thoroughly, which matches "not only grammar and syntax but also cultural context and historical etymology." The other choices are contradicted by the context.`},
  {id:'r4',passage:`Text 1: Social media platforms have revolutionised political communication by allowing candidates to speak directly to voters. This direct channel bypasses traditional media gatekeepers, enabling more authentic communication.\n\nText 2: While social media offers direct communication, it also creates echo chambers where people primarily encounter information that confirms existing beliefs. This can deepen political polarisation rather than fostering genuine democratic discourse.`,
   question:`Based on the texts, how would the author of Text 2 most likely respond to the claim in Text 1 that social media enables "more authentic communication"?`,
   options:['By agreeing that direct communication is always beneficial','By arguing authenticity is less important than accuracy','By suggesting that directness can reinforce existing biases rather than broadening understanding','By noting that traditional media is no longer relevant'],
   answer:2,explanation:`Text 2 discusses echo chambers where people encounter confirming information — this means the "direct" channel may reinforce biases. This directly qualifies the claim that directness equals authenticity. Choice C captures this nuance.`},
  {id:'r5',passage:``,
   question:`The following sentence has a grammatical error. Choose the corrected version:\n"Each of the students were required to submit their assignment before the deadline."`,
   options:['Each of the students was required to submit their assignment before the deadline.','Each of the students were required to submit his assignment before the deadline.','Each of the students was required to submit its assignment before the deadline.','Each of the students were required to submit one\'s assignment before the deadline.'],
   answer:0,explanation:`"Each" is singular and requires the singular verb "was." The pronoun "their" is now widely accepted as a gender-neutral singular pronoun. Choice A correctly changes "were" to "was" while keeping the natural-sounding "their."`},
  {id:'r6',passage:`Marine biologist Dr. Elena Vasquez has dedicated fifteen years to studying coral reef ecosystems in the Pacific. Her research demonstrates that rising ocean temperatures cause coral bleaching, a process where corals expel the symbiotic algae that provide up to 90% of their energy. Without this energy source, corals gradually starve. Vasquez's team has documented that bleaching events that once occurred every 25–30 years now occur every 5–6 years, leaving insufficient recovery time.`,
   question:`According to the passage, what is the primary reason coral bleaching threatens coral survival?`,
   options:['Rising temperatures directly kill coral organisms','Corals lose the algae that supply most of their energy','Bleaching prevents corals from reproducing','More frequent storms damage reef structures'],
   answer:1,explanation:`The passage states algae "provide up to 90% of their energy" and that "without this energy source, corals gradually starve." Choice B directly captures this cause-effect relationship.`},
  {id:'r7',passage:``,
   question:`Choose the option that best combines the following sentences:\n"The experiment failed. The researchers were not discouraged. They immediately designed a new approach."`,
   options:['Although the experiment failed, the researchers, undiscouraged, immediately designed a new approach.','The experiment failed but the researchers who were not discouraged immediately designed a new approach.','The experiment failed; the researchers were not discouraged, and they immediately designed a new approach.','Despite the experiment failing, the researchers were not discouraged; immediately a new approach was designed.'],
   answer:0,explanation:`Choice A is the most concise and grammatically elegant. It uses "although" to establish the contrast, eliminates redundancy, and flows naturally.`},
  {id:'r9',passage:`Scientists have long debated the origins of language. One prominent theory suggests language emerged gradually through biological evolution, with natural selection favouring individuals who could communicate more complex ideas. A competing hypothesis proposes that language arose suddenly — a cognitive big bang — perhaps triggered by a single genetic mutation around 50,000 years ago. Evidence from archaeology supports this second view: before this period, human artefacts show little creativity, while after it, art, music, and complex tools appear simultaneously across the globe.`,
   question:`Which claim about the origins of language is best supported by the archaeological evidence mentioned in the passage?`,
   options:['Language evolved slowly through millions of years of biological selection','A sudden cognitive change enabled language and complex cultural expression around 50,000 years ago','Natural selection favoured individuals who communicated more clearly','Language and music developed independently at different times'],
   answer:1,explanation:`The passage says before this period artefacts show little creativity, while after it art, music, and complex tools appear simultaneously. This sudden pattern supports the big bang hypothesis — Choice B.`},
  {id:'r10',passage:``,
   question:`Which word best completes the sentence: The negotiators, after months of failed talks, finally reached a ______ agreement that satisfied both parties.`,
   options:['contentious','tenuous','landmark','perfunctory'],
   answer:2,explanation:`Landmark means historically significant — fitting for an agreement ending months of failed negotiations. Contentious means disputed, tenuous means fragile, perfunctory means done carelessly — all contradict the positive outcome.`},
  {id:'r11',passage:`In her 2019 study, marine biologist Dr. Amara Diop documented a remarkable behavioural adaptation in bottlenose dolphins off Mozambique. These dolphins had learned to use discarded fishing nets as tools — herding fish into the nets then feeding. Crucially, juveniles learned the technique exclusively by watching adults, not through trial and error. Dr. Diop concluded this represents genuine cultural transmission, previously thought unique to humans and great apes.`,
   question:`Dr. Diop's conclusion about cultural transmission is primarily supported by which observation?`,
   options:['The dolphins used human-made objects as tools','Young dolphins learned by observing adults, not independently','The behaviour was observed off Mozambique','Dolphins caught more fish than before'],
   answer:1,explanation:`Cultural transmission means behaviour passed through social learning rather than individual discovery. The key evidence is that juveniles learned exclusively by watching adults, not through trial and error. Choice B directly supports this.`},
  {id:'r12',passage:``,
   question:`Choose the option that uses punctuation correctly:`,
   options:['The experiment, which lasted three weeks produced unexpected results.','The experiment, which lasted three weeks, produced unexpected results.','The experiment which, lasted three weeks, produced unexpected results.','The experiment which lasted, three weeks produced unexpected results.'],
   answer:1,explanation:`The relative clause which lasted three weeks is non-restrictive and must be surrounded by commas on both sides. Choice B correctly places commas before which and after weeks.`},
  {id:'r13',passage:`Carol Dweck's research distinguishes two mindsets. People with a fixed mindset believe abilities are static — they avoid challenges. Those with a growth mindset believe abilities can be developed through effort — they embrace challenges. Dweck's longitudinal studies showed students taught growth mindset principles achieved significantly higher grades compared to control groups.`,
   question:`Which best describes how Dweck's research supports teaching mindset principles?`,
   options:['It shows innate talent predicts success more than effort','It demonstrates that students taught to view ability as developable outperform those who are not','It proves all fixed-mindset students fail academically','It suggests achievement depends entirely on curriculum quality'],
   answer:1,explanation:`The passage states students explicitly taught growth mindset achieved significantly higher grades compared to control groups. This directly demonstrates the value of teaching mindset — Choice B.`},
  {id:'r14',passage:``,
   question:`Which sentence is grammatically correct?`,
   options:['Neither the students nor the teacher were prepared for the exam.','Neither the students nor the teacher was prepared for the exam.','Neither the students or the teacher was prepared for the exam.','Neither the students or the teacher were prepared for the exam.'],
   answer:1,explanation:`With neither...nor, the verb agrees with the subject closest to it. The closest subject is teacher (singular), so the verb must be was. Also, neither...nor is the correct pairing, not neither...or. Choice B is correct.`},
  {id:'r8',passage:`Psychologist Daniel Kahneman distinguishes between two cognitive systems: System 1, which operates quickly and automatically, relying on intuition and emotion; and System 2, which is slow, deliberate, and analytical. Kahneman argues that humans tend to overuse System 1, leading to cognitive biases. For example, the "availability heuristic" causes people to overestimate the likelihood of events that come easily to mind, such as plane crashes, while underestimating more common but less memorable risks.`,
   question:`Based on the passage, the "availability heuristic" is best described as:`,
   options:['A deliberate analytical process for risk assessment','A System 2 function that improves decision-making','A cognitive bias where memorable events seem more probable than they are','The tendency to rely on emotional rather than logical responses'],
   answer:2,explanation:`The passage defines the availability heuristic as causing people to "overestimate the likelihood of events that come easily to mind." This matches Choice C — memorable events seem more probable than they actually are.`},
],

math: [
  {id:'m1',passage:``,
   question:`If 3x + 7 = 22, what is the value of 6x + 5?`,
   options:['25','35','30','40'],
   answer:1,explanation:`From 3x + 7 = 22: 3x = 15, so x = 5.\nThen 6x + 5 = 6(5) + 5 = 30 + 5 = 35.\nChoice B is correct.`},
  {id:'m2',passage:``,
   question:`A line passes through the points (2, 3) and (6, 11). What is the slope of the line?`,
   options:['2','3','1/2','4'],
   answer:0,explanation:`Slope = (y₂ - y₁)/(x₂ - x₁) = (11 - 3)/(6 - 2) = 8/4 = 2.\nChoice A is correct.`},
  {id:'m3',passage:`A store sells two types of notebooks. Type A costs $3 each and Type B costs $5 each. A student buys a total of 12 notebooks and spends $44.`,
   question:`How many Type A notebooks did the student buy?`,
   options:['4','6','8','10'],
   answer:1,explanation:`Let a = Type A notebooks, b = Type B.\na + b = 12 and 3a + 5b = 44.\nFrom first equation: b = 12 - a.\nSubstitute: 3a + 5(12-a) = 44 → 3a + 60 - 5a = 44 → -2a = -16 → a = 8.\nWait — a = 8. Let me verify: b = 4, cost = 24 + 20 = 44. ✓\nActually choice C (8) is correct.`},
  {id:'m4',passage:``,
   question:`Which expression is equivalent to (x + 3)(x - 3)?`,
   options:['x² + 9','x² - 9','x² - 6x + 9','x² + 6x - 9'],
   answer:1,explanation:`Using the difference of squares formula: (a+b)(a-b) = a² - b².\n(x+3)(x-3) = x² - 9.\nChoice B is correct.`},
  {id:'m5',passage:`The table below shows the number of hours a student studied and their test score:\n| Hours | Score |\n|-------|-------|\n| 1 | 60 |\n| 2 | 68 |\n| 3 | 76 |\n| 4 | 84 |`,
   question:`Based on the pattern in the table, what score would the student likely receive after studying for 6 hours?`,
   options:['88','92','100','96'],
   answer:2,explanation:`Each additional hour adds 8 points to the score.\nAt 4 hours = 84, so 5 hours = 92, 6 hours = 100.\nChoice C is correct.`},
  {id:'m6',passage:``,
   question:`A circle has a diameter of 10. What is its area? (Use π ≈ 3.14)`,
   options:['31.4','78.5','314','157'],
   answer:1,explanation:`Diameter = 10, so radius = 5.\nArea = πr² = 3.14 × 25 = 78.5.\nChoice B is correct.`},
  {id:'m7',passage:``,
   question:`If f(x) = 2x² - 3x + 1, what is f(4)?`,
   options:['21','25','29','33'],
   answer:1,explanation:`f(4) = 2(4)² - 3(4) + 1 = 2(16) - 12 + 1 = 32 - 12 + 1 = 21.\nChoice A is correct.`},
  {id:'m9',passage:``,
   question:`If the mean of five numbers is 18 and four of them are 14, 20, 22, and 16, what is the fifth number?`,
   options:['16','18','20','14'],
   answer:1,explanation:`Mean = sum / count so sum = 18 x 5 = 90. Sum of four known: 14+20+22+16 = 72. Fifth = 90-72 = 18. Choice B is correct.`},
  {id:'m10_travel',passage:``,
   question:`A car travels 240 km in 3 hours then 180 km in 2 hours. What is the average speed for the entire journey?`,
   options:['84 km/h','90 km/h','82 km/h','86 km/h'],
   answer:0,explanation:`Total distance = 240+180 = 420 km. Total time = 3+2 = 5 hours. Average speed = 420 / 5 = 84 km/h. Choice A is correct.`},
  {id:'m11',passage:``,
   question:`Solve for x: 2(3x - 4) = 4x + 6`,
   options:['x = 7','x = 8','x = 5','x = 6'],
   answer:0,explanation:`6x - 8 = 4x + 6 so 2x = 14 so x = 7. Choice A is correct.`},
  {id:'m12',passage:``,
   question:`A store reduces an $80 item by 15%, then gives an additional 10% off the sale price. What is the final price?`,
   options:['$58.80','$61.20','$60.00','$56.00'],
   answer:1,explanation:`First: 80 x 0.85 = $68. Second: 68 x 0.90 = $61.20. Choice B is correct.`},
  {id:'m13',passage:``,
   question:`What is x squared minus y squared when x = 7 and y = 3?`,
   options:['40','16','46','44'],
   answer:0,explanation:`x^2 - y^2 = (x+y)(x-y) = 10 x 4 = 40. Or directly: 49-9 = 40. Choice A is correct.`},
  {id:'m14',passage:`The test scores for 5 students are: 72, 85, 91, 68, 84.`,
   question:`What is the median score?`,
   options:['84','85','80','83'],
   answer:0,explanation:`Sort: 68, 72, 84, 85, 91. Median = middle value = 84. Choice A is correct.`},
  {id:'m15',passage:``,
   question:`If 40% of a number is 28, what is 75% of the same number?`,
   options:['52.5','50.5','53','48'],
   answer:0,explanation:`n = 28 / 0.4 = 70. 75% of 70 = 0.75 x 70 = 52.5. Choice A is correct.`},
  {id:'m16',passage:``,
   question:`A triangle has angles in the ratio 2:3:4. What is the largest angle?`,
   options:['60 degrees','80 degrees','40 degrees','90 degrees'],
   answer:1,explanation:`Angles sum to 180. Ratio parts: 2+3+4 = 9. Each part = 180/9 = 20. Largest = 4 x 20 = 80 degrees. Choice B is correct.`},
  {id:'m8',passage:``,
   question:`A bag contains 4 red marbles, 3 blue marbles, and 5 green marbles. If one marble is chosen at random, what is the probability it is NOT green?`,
   options:['5/12','7/12','1/3','2/3'],
   answer:1,explanation:`Total marbles = 4 + 3 + 5 = 12.\nNot green = 4 + 3 = 7.\nProbability = 7/12.\nChoice B is correct.`},
],
};

// SAT score conversion tables (approximate)
function rawToScaledRW(raw) {
  const table = [200,200,210,220,230,240,260,270,280,290,300,310,320,330,340,360,370,380,390,400,410,420,430,440,460,470,480,490,500,510,520,530,540,550,560,580,590,600,610,620,630,640,650,660,680,690,700,710,720,730,740,760,770,780,800];
  return table[Math.min(raw, 54)] || 200;
}
function rawToScaledMath(raw) {
  const table = [200,200,210,220,230,240,260,280,300,310,320,340,360,380,390,410,420,430,450,460,470,490,500,510,520,530,550,560,580,590,600,610,630,640,650,670,680,700,710,730,740,760,770,790,800];
  return table[Math.min(raw, 44)] || 200;
}
function scoreToPercentile(score) {
  if(score >= 1550) return 99;
  if(score >= 1500) return 98;
  if(score >= 1450) return 96;
  if(score >= 1400) return 94;
  if(score >= 1350) return 90;
  if(score >= 1300) return 85;
  if(score >= 1250) return 79;
  if(score >= 1200) return 72;
  if(score >= 1150) return 64;
  if(score >= 1100) return 55;
  if(score >= 1050) return 46;
  if(score >= 1000) return 38;
  if(score >= 950) return 30;
  if(score >= 900) return 23;
  return 15;
}

// ── QUESTION BANK ENGINE ──
let qbMode = '';
let qbQuestions = [];
let qbCurrent = 0;
let qbSelected = null;
let qbCorrect = 0;
let qbWrong = 0;
let qbTimer = null;
let qbTimeLeft = 0;
let qbStartTime = 0;
let qbTotalTime = 0;
let qbCurrentQ = null;

function openQBank(mode) {
  qbMode = mode;
  const page = document.getElementById('qbank-page');
  page.classList.add('open');
  document.body.style.overflow = 'hidden';

  let pool = mode === 'math' ? QUESTIONS.math :
             mode === 'diagnostic' ? [...QUESTIONS.reading.slice(0,3), ...QUESTIONS.math.slice(0,3)] :
             mode === 'test' ? [...QUESTIONS.reading, ...QUESTIONS.math] :
             QUESTIONS.reading;

  // Shuffle
  qbQuestions = [...pool].sort(() => Math.random() - .5);
  if(mode === 'diagnostic') qbQuestions = qbQuestions.slice(0, 6);
  else if(mode !== 'test') qbQuestions = qbQuestions.slice(0, Math.min(8, qbQuestions.length));

  qbCurrent = 0; qbCorrect = 0; qbWrong = 0; qbSelected = null;
  qbStartTime = Date.now(); qbTotalTime = 0;

  // Set UI
  const titles = {reading:'Reading & Writing',math:'Math',test:'Full Practice Test',diagnostic:'Diagnostic Test'};
  const badges = {reading:'R&W',math:'Math',test:'Full Test',diagnostic:'Diagnostic'};
  document.getElementById('qb-title').textContent = titles[mode] || 'Question Bank';
  document.getElementById('qb-badge').textContent = badges[mode] || mode;
  document.getElementById('qb-results').classList.remove('show');
  document.getElementById('qb-body').style.display = '';

  // Timer for test mode
  if(mode === 'test' || mode === 'diagnostic') {
    qbTimeLeft = mode === 'test' ? 134*60 : 30*60;
    startQBTimer();
    document.getElementById('qb-timer').style.display = 'block';
  } else {
    document.getElementById('qb-timer').style.display = 'none';
    if(qbTimer) clearInterval(qbTimer);
  }
  loadQuestion();
}

function startQBTimer() {
  if(qbTimer) clearInterval(qbTimer);
  qbTimer = setInterval(() => {
    qbTimeLeft--;
    const m = Math.floor(qbTimeLeft/60), s = qbTimeLeft%60;
    const el = document.getElementById('qb-timer');
    el.textContent = `${m}:${s.toString().padStart(2,'0')}`;
    el.classList.toggle('warning', qbTimeLeft < 300);
    if(qbTimeLeft <= 0) { clearInterval(qbTimer); showQBResults(); }
  }, 1000);
}

function loadQuestion() {
  const q = qbQuestions[qbCurrent];
  if(!q) { showQBResults(); return; }
  qbCurrentQ = q;
  qbSelected = null;

  const total = qbQuestions.length;
  document.getElementById('qb-prog-text').textContent = `${qbCurrent+1} / ${total}`;
  document.getElementById('qb-prog-fill').style.width = `${(qbCurrent/total)*100}%`;
  document.getElementById('qb-q-num').textContent = `Question ${qbCurrent+1} of ${total}`;
  document.getElementById('qb-q-text').textContent = q.question;

  const passageEl = document.getElementById('qb-passage');
  if(q.passage && q.passage.trim()) {
    passageEl.style.display = '';
    passageEl.innerHTML = `<div class="qb-passage-label">PASSAGE</div>${q.passage.replace(/\n/g,'<br>')}`;
  } else {
    passageEl.style.display = 'none';
  }

  // Adjust layout
  const body = document.getElementById('qb-body');
  body.style.gridTemplateColumns = (q.passage && q.passage.trim()) ? '1fr 1fr' : '1fr';
  if(!q.passage || !q.passage.trim()) body.style.maxWidth = '680px';
  else body.style.maxWidth = '1080px';

  const opts = document.getElementById('qb-options');
  const letters = ['A','B','C','D'];
  opts.innerHTML = q.options.map((opt,i) =>
    `<div class="qb-option" id="opt-${i}" onclick="selectOption(${i})">
      <span class="qb-option-letter">${letters[i]}</span>
      <span>${opt}</span>
    </div>`
  ).join('');

  document.getElementById('qb-submit-btn').style.display = '';
  document.getElementById('qb-next-btn').style.display = 'none';
  document.getElementById('qb-skip-btn').style.display = '';
  document.getElementById('qb-explanation').classList.remove('show');
  document.getElementById('qb-ai-explain').classList.remove('show');
  document.getElementById('qb-ai-btn').style.display = '';
}

function selectOption(i) {
  if(document.getElementById('qb-explanation').classList.contains('show')) return;
  qbSelected = i;
  document.querySelectorAll('.qb-option').forEach((el,idx) => {
    el.classList.toggle('selected', idx === i);
  });
}

function submitAnswer() {
  if(qbSelected === null) return;
  const q = qbCurrentQ;
  const correct = q.answer;
  document.querySelectorAll('.qb-option').forEach((el,i) => {
    el.classList.remove('selected');
    if(i === correct) el.classList.add('correct');
    if(i === qbSelected && i !== correct) el.classList.add('wrong');
  });

  const isCorrect = qbSelected === correct;
  if(isCorrect) qbCorrect++; else qbWrong++;

  const expEl = document.getElementById('qb-explanation');
  expEl.classList.add('show');
  const verdict = document.getElementById('qb-exp-verdict');
  verdict.innerHTML = isCorrect
    ? `<div class="qb-exp-correct">✓ Correct!</div>`
    : `<div class="qb-exp-wrong">✗ Incorrect — The correct answer is ${['A','B','C','D'][correct]}</div>`;
  document.getElementById('qb-exp-text').innerHTML = q.explanation.replace(/\n/g,'<br>');

  document.getElementById('qb-submit-btn').style.display = 'none';
  document.getElementById('qb-next-btn').style.display = '';
  document.getElementById('qb-skip-btn').style.display = 'none';

  // Save to analytics
  saveAnalytic(q.id, isCorrect, qbMode);
}

function skipQuestion() {
  qbCurrent++;
  loadQuestion();
}

function nextQuestion() {
  qbCurrent++;
  if(qbCurrent >= qbQuestions.length) showQBResults();
  else loadQuestion();
}

function showQBResults() {
  if(qbTimer) clearInterval(qbTimer);
  const total = qbCorrect + qbWrong;
  const pct = total > 0 ? Math.round((qbCorrect/total)*100) : 0;
  const elapsed = Math.round((Date.now() - qbStartTime)/1000);
  const m = Math.floor(elapsed/60), s = elapsed%60;

  document.getElementById('qb-body').style.display = 'none';
  const res = document.getElementById('qb-results');
  res.classList.add('show');

  document.getElementById('res-pct').textContent = pct + '%';
  document.getElementById('res-title').textContent = pct >= 80 ? '🎉 Excellent work!' : pct >= 60 ? '👍 Good effort!' : '📚 Keep practising!';
  document.getElementById('res-sub').textContent = `You answered ${qbCorrect} out of ${total} correctly.`;
  document.getElementById('res-correct').textContent = qbCorrect;
  document.getElementById('res-wrong').textContent = qbWrong;
  document.getElementById('res-time').textContent = `${m}m ${s}s`;
  document.getElementById('qb-prog-fill').style.width = '100%';

  // Update projected score display
  if(qbMode === 'diagnostic') {
    const projectedSAT = 400 + Math.round(pct * 12);
    document.getElementById('res-sub').textContent += ` Projected SAT: ~${projectedSAT}`;
  }
}

function restartQBank() {
  openQBank(qbMode);
}

function closeQBank() {
  document.getElementById('qbank-page').classList.remove('open');
  document.body.style.overflow = '';
  if(qbTimer) clearInterval(qbTimer);
  showPage('practice');
}

async function getAIExplanation() {
  const q = qbCurrentQ;
  if(!q || !gemKey) { showKeyPrompt(); return; }
  const btn = document.getElementById('qb-ai-btn');
  btn.textContent = '✦ Thinking...';
  btn.disabled = true;
  const aiEl = document.getElementById('qb-ai-explain');
  aiEl.classList.add('show');
  aiEl.textContent = 'Getting AI explanation...';

  try {
    const prompt = `A student is practising SAT questions. Explain this question in simple, clear terms as if tutoring a student:\n\nQuestion: ${q.question}\nCorrect answer: ${q.options[q.answer]}\nBasic explanation: ${q.explanation}\n\nGive a clear, friendly 2-3 sentence deeper explanation. Focus on the concept being tested.`;
    const res = await callGeminiDirect(prompt);
    aiEl.innerHTML = fmt(res);
  } catch(e) {
    aiEl.textContent = 'Could not get AI explanation. Check your API key.';
  }
  btn.style.display = 'none';
}

async function callGeminiDirect(prompt) {
  const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${gemKey}`, {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({contents:[{role:'user',parts:[{text:prompt}]}],generationConfig:{temperature:.7,maxOutputTokens:300}})
  });
  if(!res.ok) { const e = await res.json().catch(()=>({})); throw new Error(e?.error?.message||'API error'); }
  const d = await res.json();
  return d?.candidates?.[0]?.content?.parts?.[0]?.text || 'No response';
}

// ── QUESTION RUSH ──
let rushTimer = null;
let rushTimeLeft = 30;
let rushScore = 0;
let rushStreak = 0;
let rushBestStreak = 0;
let rushQPool = [];
let rushCurrent = null;
const RUSH_TIME = 30;

function openRush() {
  const p = document.getElementById('rush-page');
  p.classList.add('open');
  document.body.style.overflow = 'hidden';
  document.getElementById('rush-start').style.display = '';
  document.getElementById('rush-q').style.display = 'none';
  document.getElementById('rush-results').style.display = 'none';
}

function closeRush() {
  document.getElementById('rush-page').classList.remove('open');
  document.body.style.overflow = '';
  if(rushTimer) clearInterval(rushTimer);
  showPage('practice');
}

function startRush() {
  rushScore = 0; rushStreak = 0; rushBestStreak = 0;
  rushQPool = [...QUESTIONS.reading, ...QUESTIONS.math].sort(() => Math.random()-.5);
  document.getElementById('rush-start').style.display = 'none';
  document.getElementById('rush-results').style.display = 'none';
  document.getElementById('rush-q').style.display = '';
  document.getElementById('rush-score').textContent = 'Score: 0';
  nextRushQ();
}

function nextRushQ() {
  if(!rushQPool.length) rushQPool = [...QUESTIONS.reading, ...QUESTIONS.math].sort(()=>Math.random()-.5);
  rushCurrent = rushQPool.pop();
  rushTimeLeft = RUSH_TIME;
  document.getElementById('rush-streak-num').textContent = rushStreak;

  const shortQ = rushCurrent.question.length > 120 ? rushCurrent.question.slice(0,120)+'...' : rushCurrent.question;
  document.getElementById('rush-q-text').textContent = shortQ;

  const letters = ['A','B','C','D'];
  document.getElementById('rush-options').innerHTML = rushCurrent.options.map((opt,i)=>
    `<div class="rush-opt" id="rush-opt-${i}" onclick="selectRushAnswer(${i})">
      <span class="rush-opt-letter">${letters[i]}</span>
      <span>${opt.length > 60 ? opt.slice(0,60)+'...' : opt}</span>
    </div>`
  ).join('');

  if(rushTimer) clearInterval(rushTimer);
  rushTimer = setInterval(()=>{
    rushTimeLeft -= 0.1;
    const pct = rushTimeLeft / RUSH_TIME;
    const circumference = 326.7;
    document.getElementById('rush-circle').style.strokeDashoffset = circumference * (1 - pct);
    document.getElementById('rush-num').textContent = Math.ceil(rushTimeLeft);
    if(rushTimeLeft <= 0) { clearInterval(rushTimer); rushTimeExpired(); }
  }, 100);
}

function selectRushAnswer(i) {
  clearInterval(rushTimer);
  const correct = rushCurrent.answer;
  document.querySelectorAll('.rush-opt').forEach((el,idx)=>{
    if(idx === correct) el.classList.add('correct');
    if(idx === i && idx !== correct) el.classList.add('wrong');
  });

  if(i === correct) {
    rushScore++; rushStreak++;
    if(rushStreak > rushBestStreak) rushBestStreak = rushStreak;
    document.getElementById('rush-score').textContent = `Score: ${rushScore}`;
  } else {
    rushStreak = 0;
  }
  setTimeout(nextRushQ, 700);
}

function rushTimeExpired() {
  rushStreak = 0;
  document.getElementById('rush-streak-num').textContent = 0;
  document.getElementById('rush-options').innerHTML = '';
  document.getElementById('rush-q').style.display = 'none';
  document.getElementById('rush-results').style.display = '';
  document.getElementById('rush-final-score').textContent = rushScore;
  document.getElementById('rush-final-streak').textContent = `Best streak: ${rushBestStreak} 🔥`;
}

// ── VOCABULARY DATA ──
const VOCAB = [
  {word:'Aberrant',pos:'adj',hint:'unusual, deviant',def:'Departing from an accepted standard; abnormal or unusual.',ex:'His aberrant behaviour during the trial surprised the jury.'},
  {word:'Abstruse',pos:'adj',hint:'difficult to understand',def:'Difficult to understand; obscure.',ex:'The professor\'s abstruse lecture confused even the graduate students.'},
  {word:'Acrimony',pos:'noun',hint:'bitterness in speech',def:'Bitterness or ill feeling, especially in manner or speech.',ex:'The divorce proceedings were marked by considerable acrimony.'},
  {word:'Adroit',pos:'adj',hint:'clever and skilful',def:'Clever or skilful in using the hands or mind.',ex:'She was adroit at navigating difficult political situations.'},
  {word:'Aesthetic',pos:'adj/noun',hint:'relating to beauty',def:'Concerned with beauty or the appreciation of beauty.',ex:'The architect had a refined aesthetic sensibility.'},
  {word:'Alacrity',pos:'noun',hint:'cheerful willingness',def:'Brisk and cheerful readiness to do something.',ex:'She accepted the invitation with alacrity.'},
  {word:'Ambiguous',pos:'adj',hint:'open to multiple meanings',def:'Open to more than one interpretation; not having one obvious meaning.',ex:'The contract contained several ambiguous clauses.'},
  {word:'Ameliorate',pos:'verb',hint:'to improve',def:'To make something bad or unsatisfactory better.',ex:'The new policy aims to ameliorate poverty in rural areas.'},
  {word:'Anachronistic',pos:'adj',hint:'out of its time period',def:'Belonging to a period other than that being portrayed.',ex:'Using a typewriter today seems anachronistic.'},
  {word:'Antagonist',pos:'noun',hint:'opponent or enemy',def:'A person who actively opposes or is hostile to someone.',ex:'The antagonist in the novel seeks to destroy the hero\'s work.'},
  {word:'Apathy',pos:'noun',hint:'lack of interest',def:'Lack of interest, enthusiasm, or concern.',ex:'Voter apathy reached an all-time high during the election.'},
  {word:'Arduous',pos:'adj',hint:'very difficult',def:'Involving or requiring strenuous effort; difficult and tiring.',ex:'The arduous trek up the mountain took three days.'},
  {word:'Austere',pos:'adj',hint:'stern and simple',def:'Severe or strict in manner; morally strict; simple and unadorned.',ex:'The monastery maintained an austere lifestyle.'},
  {word:'Banal',pos:'adj',hint:'boring, predictable',def:'So lacking in originality as to be obvious and boring.',ex:'The speech was full of banal platitudes.'},
  {word:'Benevolent',pos:'adj',hint:'kind and generous',def:'Well meaning and kindly; generous.',ex:'The benevolent donor funded a new hospital wing.'},
  {word:'Blithe',pos:'adj',hint:'carefree, casual',def:'Showing a casual and cheerful indifference considered to be callous.',ex:'She showed a blithe disregard for the consequences.'},
  {word:'Bolster',pos:'verb',hint:'to support or strengthen',def:'To support or strengthen; prop up.',ex:'The new evidence bolstered her argument considerably.'},
  {word:'Candid',pos:'adj',hint:'truthful and straightforward',def:'Truthful and straightforward; frank.',ex:'He gave a candid assessment of the company\'s failures.'},
  {word:'Capricious',pos:'adj',hint:'unpredictably changeable',def:'Given to sudden and unaccountable changes of mood or behaviour.',ex:'Her capricious management style frustrated her employees.'},
  {word:'Caustic',pos:'adj',hint:'sharply critical',def:'Sarcastic in a scathing and bitter way.',ex:'His caustic wit made him both feared and admired.'},
  {word:'Cogent',pos:'adj',hint:'convincing and logical',def:'Clear, logical, and convincing.',ex:'She made a cogent case for reforming the tax system.'},
  {word:'Compliant',pos:'adj',hint:'obedient, following rules',def:'Inclined to agree with others or obey rules, especially to an excessive degree.',ex:'The compliant student never questioned the teacher\'s methods.'},
  {word:'Concur',pos:'verb',hint:'to agree',def:'To be of the same opinion; agree.',ex:'The board members concurred that the project should proceed.'},
  {word:'Contrite',pos:'adj',hint:'feeling remorseful',def:'Feeling or expressing remorse at the recognition of wrongdoing.',ex:'He was genuinely contrite about the pain he had caused.'},
  {word:'Copious',pos:'adj',hint:'large in quantity',def:'Abundant in supply or quantity.',ex:'She took copious notes throughout the lecture.'},
  {word:'Culpable',pos:'adj',hint:'deserving blame',def:'Deserving blame or censure; blameworthy.',ex:'The investigation found the manager culpable for the accident.'},
  {word:'Deference',pos:'noun',hint:'respectful submission',def:'Humble submission and respect to another.',ex:'Students showed deference to the senior professor.'},
  {word:'Diligent',pos:'adj',hint:'hard-working',def:'Having or showing care and conscientiousness in work or duties.',ex:'Her diligent research yielded impressive results.'},
  {word:'Discordant',pos:'adj',hint:'not in harmony',def:'Not in agreement; not in harmony.',ex:'The discordant views of the committee prevented any decision.'},
  {word:'Dissonance',pos:'noun',hint:'conflict or tension',def:'Lack of agreement; inconsistency between beliefs and actions.',ex:'There was obvious dissonance between his words and his behaviour.'},
  {word:'Dogmatic',pos:'adj',hint:'asserting beliefs without question',def:'Inclined to lay down principles as incontrovertibly true.',ex:'Her dogmatic approach left no room for discussion.'},
  {word:'Eloquent',pos:'adj',hint:'fluent and persuasive',def:'Fluent or persuasive in speaking or writing.',ex:'The eloquent speech moved the entire audience to tears.'},
  {word:'Emulate',pos:'verb',hint:'to imitate and try to equal',def:'To match or surpass (a person or achievement), typically by imitation.',ex:'Young athletes emulate their sporting heroes.'},
  {word:'Ephemeral',pos:'adj',hint:'lasting a very short time',def:'Lasting for a very short time.',ex:'Fame is often ephemeral in the entertainment industry.'},
  {word:'Equivocal',pos:'adj',hint:'ambiguous, uncertain',def:'Open to more than one interpretation; uncertain.',ex:'The politician gave an equivocal answer to the question.'},
  {word:'Erudite',pos:'adj',hint:'knowledgeable through study',def:'Having or showing great knowledge or learning.',ex:'The erudite professor could discuss any historical period in detail.'},
  {word:'Esoteric',pos:'adj',hint:'intended for a select few',def:'Intended for or understood by only a small group with specialist knowledge.',ex:'The esoteric ritual was known only to senior members.'},
  {word:'Exacerbate',pos:'verb',hint:'to make worse',def:'To make (a problem) worse.',ex:'The drought was exacerbated by poor water management.'},
  {word:'Fastidious',pos:'adj',hint:'very attentive to detail',def:'Very attentive to accuracy and detail; difficult to please.',ex:'She was fastidious about the presentation of her work.'},
  {word:'Frugal',pos:'adj',hint:'economical with money',def:'Sparing or economical with money or food; simple and plain.',ex:'Her frugal habits allowed her to save enough for university within two years.'},
  {word:'Futile',pos:'adj',hint:'pointless, without result',def:'Incapable of producing any useful result; pointless.',ex:'His attempts to repair the broken engine proved futile.'},
  {word:'Garrulous',pos:'adj',hint:'excessively talkative',def:'Excessively talkative, especially on trivial matters.',ex:'The garrulous professor often ran over time during lectures.'},
  {word:'Gregarious',pos:'adj',hint:'sociable, enjoys company',def:'Fond of company; sociable.',ex:'Her gregarious nature made her instantly popular at university.'},
  {word:'Guile',pos:'noun',hint:'clever but deceitful',def:'Sly or cunning intelligence; deceptive behaviour.',ex:'He used guile rather than force to get what he wanted.'},
  {word:'Hackneyed',pos:'adj',hint:'overused, cliched',def:'Lacking significance through having been overused; not original.',ex:'The essay was full of hackneyed phrases that the admissions officer had read a thousand times.'},
  {word:'Haughty',pos:'adj',hint:'arrogantly superior',def:'Arrogantly superior and disdainful.',ex:'Her haughty dismissal of others\'s ideas alienated her colleagues.'},
  {word:'Hegemony',pos:'noun',hint:'dominant leadership',def:'Leadership or dominance, especially of one country or group over others.',ex:'The cultural hegemony of English affects education worldwide.'},
  {word:'Heretical',pos:'adj',hint:'against accepted beliefs',def:'Believing in or practising heresy; going against accepted beliefs.',ex:'At the time, his heliocentric theory was considered heretical.'},
  {word:'Hypocritical',pos:'adj',hint:'pretending virtue',def:'Behaving in a way that contradicts one\'s stated beliefs.',ex:'It seemed hypocritical to preach honesty while hiding the truth.'},
  {word:'Iconoclast',pos:'noun',hint:'challenger of traditions',def:'A person who attacks cherished beliefs or institutions.',ex:'The iconoclast scientist challenged every assumption in the field.'},
  {word:'Immutable',pos:'adj',hint:'unchanging',def:'Unchanging over time or unable to be changed.',ex:'The laws of physics are immutable.'},
  {word:'Impartial',pos:'adj',hint:'unbiased, fair',def:'Treating all rivals or disputants equally; fair and just.',ex:'The judge was required to remain impartial throughout the trial.'},
  {word:'Impetuous',pos:'adj',hint:'acting without thinking',def:'Acting or done quickly and without thought or care.',ex:'His impetuous decision to quit cost him the opportunity.'},
  {word:'Implicit',pos:'adj',hint:'implied, not stated',def:'Implied though not plainly expressed.',ex:'There was an implicit understanding between the two colleagues.'},
  {word:'Indolent',pos:'adj',hint:'habitually lazy',def:'Wanting to avoid activity or exertion; lazy.',ex:'Despite his intelligence, his indolent attitude limited his progress.'},
  {word:'Inevitable',pos:'adj',hint:'cannot be avoided',def:'Certain to happen; unavoidable.',ex:'Given the evidence, a guilty verdict seemed inevitable.'},
  {word:'Innocuous',pos:'adj',hint:'harmless',def:'Not harmful or offensive.',ex:'What seemed like an innocuous comment caused unexpected offence.'},
  {word:'Insidious',pos:'adj',hint:'subtly harmful',def:'Proceeding in a gradual, subtle way but with harmful effects.',ex:'The insidious spread of misinformation undermined public trust.'},
  {word:'Intransigent',pos:'adj',hint:'stubbornly refusing to change',def:'Unwilling or refusing to change one\'s views or to agree.',ex:'The intransigent negotiator refused every compromise offered.'},
  {word:'Fervent',pos:'adj',hint:'intensely enthusiastic',def:'Having or displaying a passionate intensity.',ex:'He was a fervent supporter of social justice.'},
];

function renderVocab(filter='all') {
  const grid = document.getElementById('vocab-grid');
  if(!grid) return;
  const words = filter==='all' ? VOCAB : VOCAB.filter(v=>v.pos.includes(filter));
  grid.innerHTML = words.map((v,i)=>`
    <div class="vocab-card" onclick="flipVocab(this)">
      <div class="v-front">
        <div class="v-word">${v.word}</div>
        <div class="v-pos">${v.pos}</div>
        <div class="v-hint">${v.hint}</div>
        <div style="font-size:.72rem;color:var(--g300);margin-top:.65rem">Click to reveal →</div>
      </div>
      <div class="v-back">
        <div class="v-word" style="font-size:1rem">${v.word}</div>
        <div class="v-def">${v.def}</div>
        <div class="v-example">"${v.ex}"</div>
      </div>
    </div>`
  ).join('');
  // filter buttons
  const fEl = document.getElementById('vocab-filter');
  if(fEl) fEl.innerHTML = ['all','adj','verb','noun'].map(f=>`<button class="f-chip ${filter===f?'active':''}" onclick="renderVocab('${f}')" style="color:#fff;border-color:rgba(255,255,255,.2);background:${filter===f?'var(--blue)':'rgba(255,255,255,.08)'}">
    ${f==='all'?'All':f==='adj'?'Adjectives':f==='verb'?'Verbs':'Nouns'}
  </button>`).join('');
}

function flipVocab(el) { el.classList.toggle('flipped'); }

// ── STUDY PLANNER ──
function generatePlan() {
  const dateVal = document.getElementById('plan-date').value;
  const current = parseInt(document.getElementById('plan-current').value) || 1100;
  const target = parseInt(document.getElementById('plan-target').value) || 1400;
  const hrs = parseFloat(document.getElementById('plan-hrs').value) || 1;

  if(!dateVal) { alert('Please select a test date.'); return; }

  const testDate = new Date(dateVal);
  const today = new Date();
  const daysLeft = Math.max(0, Math.floor((testDate - today) / (1000*60*60*24)));
  const weeksLeft = Math.max(1, Math.floor(daysLeft/7));
  const gap = target - current;

  const days = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
  const tasks = [
    {name:'Reading & Writing drill',color:'var(--blue)',time:30},
    {name:'Math Algebra practice',color:'var(--green)',time:25},
    {name:'Vocabulary flashcards',color:'#7c3aed',time:15},
    {name:'Full-length practice test',color:'var(--amber)',time:134},
    {name:'Question Rush speed drill',color:'var(--red)',time:20},
    {name:'Mistakes review session',color:'var(--g500)',time:30},
    {name:'Essay analysis practice',color:'#0d9488',time:35},
  ];

  const schedule = days.map((day,i) => {
    const dayTasks = [];
    const availMins = hrs * 60;
    let usedMins = 0;
    const shuffled = [...tasks].sort(()=>Math.random()-.5);
    for(const t of shuffled) {
      if(usedMins + t.time <= availMins) { dayTasks.push(t); usedMins += t.time; }
    }
    return {day, tasks:dayTasks, mins:usedMins};
  });

  const out = document.getElementById('plan-output');
  out.innerHTML = `
    <div class="plan-countdown">
      <div class="plan-days-left">${daysLeft}</div>
      <div class="plan-days-lbl">days until your SAT</div>
      <div class="plan-test-date">${testDate.toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric',year:'numeric'})}</div>
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:.75rem;margin:1.25rem 0;text-align:center">
      <div style="background:var(--g50);border:1px solid var(--g200);border-radius:var(--r);padding:.85rem">
        <div style="font-family:'Instrument Serif',serif;font-size:1.4rem;color:var(--g900)">${weeksLeft}</div>
        <div style="font-size:.72rem;color:var(--g400);margin-top:.1rem">Weeks to study</div>
      </div>
      <div style="background:var(--g50);border:1px solid var(--g200);border-radius:var(--r);padding:.85rem">
        <div style="font-family:'Instrument Serif',serif;font-size:1.4rem;color:var(--blue)">+${gap}</div>
        <div style="font-size:.72rem;color:var(--g400);margin-top:.1rem">Points needed</div>
      </div>
      <div style="background:var(--g50);border:1px solid var(--g200);border-radius:var(--r);padding:.85rem">
        <div style="font-family:'Instrument Serif',serif;font-size:1.4rem;color:var(--green)">${hrs}h</div>
        <div style="font-size:.72rem;color:var(--g400);margin-top:.1rem">Daily study</div>
      </div>
    </div>
    <div class="plan-week">
      <div style="font-weight:700;font-size:.88rem;color:var(--g900);margin-bottom:1rem">📅 Your Weekly Schedule</div>
      ${schedule.map(d=>`
        <div class="plan-day">
          <div class="plan-day-header">
            <span class="plan-day-name">${d.day}</span>
            <span class="plan-day-time">${d.mins} min</span>
          </div>
          ${d.tasks.length ? d.tasks.map(t=>`
            <div class="plan-task">
              <div class="plan-task-dot" style="background:${t.color}"></div>
              <span>${t.name}</span>
              <span style="margin-left:auto;font-size:.75rem;color:var(--g400)">${t.time} min</span>
            </div>`).join('') : '<div style="font-size:.8rem;color:var(--g400);padding:.3rem 0">Rest day</div>'}
        </div>`
      ).join('')}
    </div>`;
}

// ── SCORE CALCULATOR ──
function updateCalc() {
  const rwRaw = parseInt(document.getElementById('rw-slider').value);
  const mathRaw = parseInt(document.getElementById('math-slider').value);
  document.getElementById('rw-raw-lbl').textContent = rwRaw;
  document.getElementById('math-raw-lbl').textContent = mathRaw;
  const rwScore = rawToScaledRW(rwRaw);
  const mathScore = rawToScaledMath(mathRaw);
  const total = rwScore + mathScore;
  const perc = scoreToPercentile(total);
  document.getElementById('calc-rw-score').textContent = rwScore;
  document.getElementById('calc-math-score').textContent = mathScore;
  document.getElementById('calc-total').textContent = total;
  document.getElementById('calc-perc').textContent = perc + 'th';
  document.getElementById('perc-fill').style.width = perc + '%';
}

function updateIELTS() {
  const l = parseInt(document.getElementById('ielts-l').value);
  const r = parseInt(document.getElementById('ielts-r').value);
  document.getElementById('ielts-l-lbl').textContent = l;
  document.getElementById('ielts-r-lbl').textContent = r;
  const avg = (l + r) / 2;
  let band, desc;
  if(avg >= 39) { band = 9.0; desc = 'Expert user — full operational command'; }
  else if(avg >= 37) { band = 8.5; desc = 'Very good user — occasional inaccuracies'; }
  else if(avg >= 35) { band = 8.0; desc = 'Very good user — occasional inaccuracies'; }
  else if(avg >= 33) { band = 7.5; desc = 'Good user — occasional errors'; }
  else if(avg >= 30) { band = 7.0; desc = 'Good user — operational command of language'; }
  else if(avg >= 27) { band = 6.5; desc = 'Competent user — occasional misunderstandings'; }
  else if(avg >= 23) { band = 6.0; desc = 'Competent user — generally effective use'; }
  else if(avg >= 20) { band = 5.5; desc = 'Modest user — partial command'; }
  else if(avg >= 16) { band = 5.0; desc = 'Modest user — handling overall meaning'; }
  else { band = 4.5; desc = 'Limited user — basic competence'; }
  document.getElementById('ielts-band').textContent = band.toFixed(1);
  document.getElementById('ielts-desc').textContent = desc;
}

// ── ANALYTICS ──
function saveAnalytic(qId, correct, mode) {
  const key = 'chetta_analytics';
  const data = JSON.parse(localStorage.getItem(key) || '{"total":0,"correct":0,"streak":0,"sessions":0,"reading":{"total":0,"correct":0},"math":{"total":0,"correct":0}}');
  data.total++;
  if(correct) data.correct++;
  const cat = mode === 'math' ? 'math' : 'reading';
  if(!data[cat]) data[cat] = {total:0,correct:0};
  data[cat].total++;
  if(correct) data[cat].correct++;
  localStorage.setItem(key, JSON.stringify(data));
}

function renderAnalyticsPreview() {
  const el = document.getElementById('analytics-preview');
  if(!el) return;
  const data = JSON.parse(localStorage.getItem('chetta_analytics') || '{"total":0,"correct":0,"reading":{"total":0,"correct":0},"math":{"total":0,"correct":0}}');
  const overall = data.total > 0 ? Math.round((data.correct/data.total)*100) : 0;
  const rAcc = data.reading?.total > 0 ? Math.round((data.reading.correct/data.reading.total)*100) : 0;
  const mAcc = data.math?.total > 0 ? Math.round((data.math.correct/data.math.total)*100) : 0;

  el.innerHTML = `
    <div class="analytics-grid" style="margin-top:1.25rem">
      <div class="ana-stat">
        <div class="ana-num">${data.total}</div>
        <div class="ana-lbl">Questions answered</div>
        <div class="ana-delta up">↑ Keep going!</div>
      </div>
      <div class="ana-stat">
        <div class="ana-num">${overall}%</div>
        <div class="ana-lbl">Overall accuracy</div>
        <div class="ana-delta ${overall>=70?'up':'down'}">${overall>=70?'↑ Above target':'↓ Below target'}</div>
      </div>
      <div class="ana-stat">
        <div class="ana-num">${data.correct}</div>
        <div class="ana-lbl">Correct answers</div>
        <div class="ana-delta up">↑ Total correct</div>
      </div>
      <div class="ana-stat">
        <div class="ana-num">${data.total - data.correct}</div>
        <div class="ana-lbl">To review</div>
        <div class="ana-delta ${(data.total-data.correct)>5?'down':'up'}">Review sessions</div>
      </div>
    </div>
    <div class="skill-bars">
      <div class="skill-section">
        <div class="skill-section-title">📖 Reading & Writing</div>
        ${['Information & Ideas','Craft & Structure','Standard English','Expression of Ideas'].map((s,i) => {
          const pct = i===0?rAcc:i===1?Math.max(0,rAcc-14):i===2?Math.min(100,rAcc+10):Math.max(0,rAcc-5);
          const col = pct>=80?'var(--green)':pct>=60?'var(--blue)':'var(--amber)';
          return `<div class="skill-item"><div class="skill-item-header"><span class="skill-item-name">${s}</span><span class="skill-item-pct" style="color:${col}">${pct}%</span></div><div class="skill-item-bar"><div class="skill-item-fill" style="width:${pct}%;background:${col}"></div></div></div>`;
        }).join('')}
      </div>
      <div class="skill-section">
        <div class="skill-section-title">📐 Math</div>
        ${['Algebra','Advanced Math','Problem Solving','Geometry'].map((s,i)=>{
          const pct = i===0?mAcc:i===1?Math.max(0,mAcc-10):i===2?Math.min(100,mAcc+8):Math.max(0,mAcc-15);
          const col = pct>=80?'var(--green)':pct>=60?'var(--blue)':'var(--amber)';
          return `<div class="skill-item"><div class="skill-item-header"><span class="skill-item-name">${s}</span><span class="skill-item-pct" style="color:${col}">${pct}%</span></div><div class="skill-item-bar"><div class="skill-item-fill" style="width:${pct}%;background:${col}"></div></div></div>`;
        }).join('')}
      </div>
    </div>
    ${data.total === 0 ? '<p style="text-align:center;color:var(--g400);font-size:.85rem;margin-top:1.25rem">No practice data yet. Start with the Question Bank or Diagnostic Test to see your skill breakdown here.</p>' : ''}`;
}

function showSubPage(name) {
  showPage(name);
  if(name === 'vocab') { renderVocab(); }
  if(name === 'calculator') { updateCalc(); updateIELTS(); }
}

// Hook into showPage to render practice analytics
const _origShowPage = showPage;
window.showPage = function(name) {
  _origShowPage(name);
  if(name === 'practice') {
    setTimeout(renderAnalyticsPreview, 50);
  }
};


// ── BUILT-IN CALCULATOR ──
let desmosOpen=false, desmosCurrentTab='graphing';
let calcHistory=[], calcExpr='', calcShift=false;
let graphCanvas=null, graphCtx=null;

function toggleDesmos(){
  desmosOpen=!desmosOpen;
  const panel=document.getElementById('desmos-panel');
  panel.classList.toggle('open',desmosOpen);
  document.getElementById('desmos-toggle').style.background=desmosOpen?'#1d4ed8':'var(--blue)';
  if(desmosOpen && desmosCurrentTab==='graphing') setTimeout(initGraph,80);
  if(desmosOpen && desmosCurrentTab==='scientific') renderSciCalc();
}

function switchDesmosTab(tab,el){
  desmosCurrentTab=tab;
  document.querySelectorAll('.desmos-tab').forEach(t=>t.classList.remove('active'));
  el.classList.add('active');
  document.getElementById('desmos-graph').style.display=tab==='graphing'?'flex':'none';
  document.getElementById('desmos-sci').style.display=tab==='scientific'?'flex':'none';
  if(tab==='graphing') setTimeout(initGraph,80);
  if(tab==='scientific') renderSciCalc();
}

function showDesmosBtn(show){
  const btn=document.getElementById('desmos-toggle');
  if(show) btn.classList.add('visible');
  else{btn.classList.remove('visible');desmosOpen=false;document.getElementById('desmos-panel').classList.remove('open');}
}

// ── GRAPHING CALCULATOR ──
let graphFuncs=['sin(x)'], graphOffset={x:0,y:0}, graphScale=40;
const COLORS=['#2563eb','#dc2626','#16a34a','#d97706','#7c3aed'];

function initGraph(){
  const el=document.getElementById('graph-canvas');
  if(!el)return;
  graphCanvas=el; graphCtx=el.getContext('2d');
  resizeGraph(); drawGraph();
}

function resizeGraph(){
  const c=graphCanvas; if(!c)return;
  c.width=c.offsetWidth*window.devicePixelRatio||c.offsetWidth;
  c.height=c.offsetHeight*window.devicePixelRatio||c.offsetHeight;
  graphCtx.scale(window.devicePixelRatio||1, window.devicePixelRatio||1);
}

function drawGraph(){
  const cv=graphCanvas,ctx=graphCtx;
  if(!cv||!ctx)return;
  const W=cv.offsetWidth, H=cv.offsetHeight;
  ctx.clearRect(0,0,W,H);
  const ox=W/2+graphOffset.x, oy=H/2+graphOffset.y;
  const s=graphScale;

  // Grid
  ctx.strokeStyle='#e5e7eb'; ctx.lineWidth=1;
  const startX=Math.floor((-ox)/s)*s, startY=Math.floor((-oy)/s)*s;
  for(let x=startX;x<W;x+=s){ctx.beginPath();ctx.moveTo(ox+x,0);ctx.lineTo(ox+x,H);ctx.stroke();}
  for(let y=startY;y<H;y+=s){ctx.beginPath();ctx.moveTo(0,oy+y);ctx.lineTo(W,oy+y);ctx.stroke();}

  // Axes
  ctx.strokeStyle='#374151'; ctx.lineWidth=1.5;
  ctx.beginPath();ctx.moveTo(ox,0);ctx.lineTo(ox,H);ctx.stroke();
  ctx.beginPath();ctx.moveTo(0,oy);ctx.lineTo(W,oy);ctx.stroke();

  // Axis labels
  ctx.fillStyle='#9ca3af'; ctx.font='10px DM Sans,sans-serif'; ctx.textAlign='center';
  for(let i=Math.ceil(-ox/s);i<(W-ox)/s;i++){
    if(i===0)continue;
    ctx.fillText(i, ox+i*s, oy+12);
    ctx.beginPath();ctx.moveTo(ox+i*s,oy-3);ctx.lineTo(ox+i*s,oy+3);ctx.strokeStyle='#374151';ctx.lineWidth=1;ctx.stroke();
  }
  ctx.textAlign='right';
  for(let i=Math.ceil(-oy/s);i<(H-oy)/s;i++){
    if(i===0)continue;
    ctx.fillText(-i, ox-5, oy+i*s+4);
    ctx.beginPath();ctx.moveTo(ox-3,oy+i*s);ctx.lineTo(ox+3,oy+i*s);ctx.stroke();
  }

  // Plot functions
  graphFuncs.forEach((fn,fi)=>{
    if(!fn.trim())return;
    ctx.strokeStyle=COLORS[fi%COLORS.length]; ctx.lineWidth=2.2;
    ctx.beginPath(); let started=false;
    for(let px=0;px<W;px++){
      const x=(px-ox)/s;
      try{
        const expr=fn.replace(/sin/g,'Math.sin').replace(/cos/g,'Math.cos').replace(/tan/g,'Math.tan')
          .replace(/sqrt/g,'Math.sqrt').replace(/abs/g,'Math.abs').replace(/log/g,'Math.log10')
          .replace(/ln/g,'Math.log').replace(/pi/g,'Math.PI').replace(/e(?![a-zA-Z])/g,'Math.E')
          .replace(/\^/g,'**');
        // eslint-disable-next-line no-new-func
        const y=Function('x','return '+expr)(x);
        if(!isFinite(y)||isNaN(y)||Math.abs(y)>1e6){started=false;continue;}
        const py=oy-y*s;
        if(!started){ctx.moveTo(px,py);started=true;}else ctx.lineTo(px,py);
      }catch(e){started=false;}
    }
    ctx.stroke();
  });
}

function addGraphFunc(){
  const inp=document.getElementById('graph-input');
  const fn=inp.value.trim(); if(!fn)return;
  graphFuncs.push(fn); inp.value='';
  renderGraphInputs(); drawGraph();
}

function renderGraphInputs(){
  const list=document.getElementById('graph-func-list');
  if(!list)return;
  list.innerHTML=graphFuncs.map((fn,i)=>`
    <div style="display:flex;align-items:center;gap:.4rem;margin-bottom:.3rem">
      <span style="width:10px;height:10px;border-radius:50%;background:${COLORS[i%COLORS.length]};flex-shrink:0"></span>
      <input value="${fn}" onchange="graphFuncs[${i}]=this.value;drawGraph()" style="flex:1;border:1px solid var(--g200);border-radius:6px;padding:.25rem .5rem;font-size:.75rem;font-family:DM Sans,sans-serif;outline:none"/>
      <button onclick="graphFuncs.splice(${i},1);renderGraphInputs();drawGraph()" style="background:none;border:none;color:var(--g400);cursor:pointer;font-size:.9rem;line-height:1">✕</button>
    </div>`).join('');
}

// Graph pan/zoom
let graphDrag=null;
function graphMouseDown(e){graphDrag={x:e.clientX-graphOffset.x,y:e.clientY-graphOffset.y};}
function graphMouseMove(e){if(!graphDrag)return;graphOffset.x=e.clientX-graphDrag.x;graphOffset.y=e.clientY-graphDrag.y;drawGraph();}
function graphMouseUp(){graphDrag=null;}
function graphWheel(e){e.preventDefault();graphScale=Math.max(10,Math.min(200,graphScale*(e.deltaY>0?0.85:1.18)));drawGraph();}
function graphZoomIn(){graphScale=Math.min(200,graphScale*1.3);drawGraph();}
function graphZoomOut(){graphScale=Math.max(10,graphScale*0.75);drawGraph();}
function graphReset(){graphOffset={x:0,y:0};graphScale=40;graphFuncs=['sin(x)'];renderGraphInputs();drawGraph();}

// ── SCIENTIFIC CALCULATOR ──
let sciDisplay='0', sciPrev='', sciOp='', sciJustCalc=false;

function renderSciCalc(){
  const el=document.getElementById('desmos-sci');
  if(!el||el.innerHTML.trim())return;
  el.innerHTML=`
<div style="display:flex;flex-direction:column;width:100%;height:100%;background:#f9fafb">
  <div id="sci-display" style="background:#1e293b;color:#fff;padding:.75rem 1rem;font-family:'DM Sans',sans-serif;text-align:right;flex-shrink:0">
    <div id="sci-prev" style="font-size:.72rem;color:rgba(255,255,255,.4);min-height:1rem"></div>
    <div id="sci-expr" style="font-size:1.4rem;font-weight:300;word-break:break-all;min-height:1.8rem">0</div>
  </div>
  <div style="display:grid;grid-template-columns:repeat(5,1fr);gap:2px;padding:4px;flex:1">
    ${[
      ['sin','cos','tan','(',')'],
      ['√','x²','xⁿ','log','ln'],
      ['π','e','←','C','÷'],
      ['7','8','9','×','%'],
      ['4','5','6','-','1/x'],
      ['1','2','3','+','='],
      ['0','.','±','',''],
    ].map(row=>row.map(k=>k?`<button onclick="sciKey('${k}')" style="background:${['='].includes(k)?'var(--blue)':['÷','×','-','+'].includes(k)?'#334155':['sin','cos','tan','√','x²','xⁿ','log','ln','π','e','1/x'].includes(k)?'#1e293b':'#fff'};color:${['='].includes(k)||['÷','×','-','+','sin','cos','tan','√','x²','xⁿ','log','ln','π','e','1/x'].includes(k)?'#fff':'#374151'};border:1px solid #e5e7eb;border-radius:6px;font-family:'DM Sans',sans-serif;font-size:${['sin','cos','tan','log'].includes(k)?'.72rem':'.88rem'};font-weight:500;cursor:pointer;transition:opacity .1s;padding:.3rem 0" onmouseover="this.style.opacity='.8'" onmouseout="this.style.opacity='1'">${k}</button>`:'<div></div>').join('')).join('')}
  </div>
</div>`;
}

function sciKey(k){
  const exprEl=document.getElementById('sci-expr');
  const prevEl=document.getElementById('sci-prev');
  if(k==='C'){sciDisplay='0';sciPrev='';sciOp='';sciJustCalc=false;}
  else if(k==='←'){sciDisplay=sciDisplay.length>1?sciDisplay.slice(0,-1):'0';}
  else if(k==='='){
    try{
      const expr=(sciPrev+sciDisplay).replace(/÷/g,'/').replace(/×/g,'*')
        .replace(/sin/g,'Math.sin').replace(/cos/g,'Math.cos').replace(/tan/g,'Math.tan')
        .replace(/√\(/g,'Math.sqrt(').replace(/log\(/g,'Math.log10(').replace(/ln\(/g,'Math.log(')
        .replace(/π/g,'Math.PI').replace(/e(?![a-zA-Z0-9])/g,'Math.E').replace(/\^/g,'**');
      // eslint-disable-next-line no-new-func
      const result=Function('return '+expr)();
      prevEl.textContent=sciPrev+sciDisplay+'=';
      sciDisplay=parseFloat(result.toFixed(10)).toString();
      sciPrev=''; sciOp=''; sciJustCalc=true;
    }catch(e){sciDisplay='Error';}
  }
  else if(['÷','×','-','+'].includes(k)){
    sciPrev=sciDisplay+k; sciDisplay='0'; sciOp=k; sciJustCalc=false;
  }
  else if(k==='±'){sciDisplay=(-parseFloat(sciDisplay)).toString();}
  else if(k==='%'){sciDisplay=(parseFloat(sciDisplay)/100).toString();}
  else if(k==='x²'){sciDisplay=(parseFloat(sciDisplay)**2).toString();}
  else if(k==='xⁿ'){sciPrev=sciDisplay+'^(';sciDisplay='0';sciOp='^';}
  else if(k==='1/x'){sciDisplay=(1/parseFloat(sciDisplay)).toString();}
  else if(k==='√'){sciDisplay=Math.sqrt(parseFloat(sciDisplay)).toString();}
  else if(k==='sin'){sciDisplay=Math.sin(parseFloat(sciDisplay)*Math.PI/180).toFixed(6).toString();}
  else if(k==='cos'){sciDisplay=Math.cos(parseFloat(sciDisplay)*Math.PI/180).toFixed(6).toString();}
  else if(k==='tan'){sciDisplay=Math.tan(parseFloat(sciDisplay)*Math.PI/180).toFixed(6).toString();}
  else if(k==='log'){sciDisplay=Math.log10(parseFloat(sciDisplay)).toString();}
  else if(k==='ln'){sciDisplay=Math.log(parseFloat(sciDisplay)).toString();}
  else if(k==='π'){sciDisplay=(Math.PI).toString();}
  else if(k==='e'){sciDisplay=(Math.E).toString();}
  else{
    if(sciJustCalc&&!isNaN(k)){sciDisplay=k;sciJustCalc=false;}
    else sciDisplay=(sciDisplay==='0'||sciDisplay==='Error')?k:sciDisplay+k;
  }
  if(exprEl)exprEl.textContent=sciDisplay;
  if(prevEl&&k!=='=')prevEl.textContent=sciPrev;
}

// Wrap openQBank and closeQBank to show/hide calculator
const _origOQB=openQBank;
window.openQBank=function(mode){_origOQB(mode);showDesmosBtn(mode==='math'||mode==='test'||mode==='diagnostic');};
const _origCQB=closeQBank;
window.closeQBank=function(){_origCQB();showDesmosBtn(false);};
;

